// routes/userRoutes.js
const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const categoryController = require('../controllers/categoriesController');
const subcategoryController = require('../controllers/subcategoriesController');
const productController = require('../controllers/productsController');
const addressController = require('../controllers/addressController');
const orderController = require('../controllers/orderController');
const uploadPhotoController = require('../controllers/uploadPhotoController')
const upload = require('../middleware/upload');
const adminController = require('../controllers/adminController');
const authController = require('../controllers/loginController');
const paymentController = require('../controllers/paymentController');

const roleController = require('../controllers/rolesController')

const { AdminauthMiddleware, userAuthMiddleware, combinedAuthMiddleware } = require('../middleware/authMiddleware');
 
//routing for User
router.get('/users', AdminauthMiddleware, userController.getUsers);
router.get('/users/:id', AdminauthMiddleware, userController.getUser);
router.post('/users',  userController.createUser);
router.put('/users/:id', combinedAuthMiddleware, userController.updateUser);
router.delete('/users/:id', combinedAuthMiddleware, userController.deleteUser);


//routing for categories
router.get('/categories', combinedAuthMiddleware, categoryController.getCategories);
router.get('/categories/:id', combinedAuthMiddleware, categoryController.getCategory);
router.post('/categories', AdminauthMiddleware, categoryController.createCategory);
router.put('/categories/:id', AdminauthMiddleware, categoryController.updateCategory);
router.delete('/categories/:id', AdminauthMiddleware, categoryController.deleteCategory);

//routing for subCategories
router.get('/subcategories', combinedAuthMiddleware, subcategoryController.getSubcategories);
router.get('/subcategories/:id', combinedAuthMiddleware, subcategoryController.getSubcategory);
router.post('/subcategories', AdminauthMiddleware, subcategoryController.createSubcategory);
router.put('/subcategories/:id', AdminauthMiddleware, subcategoryController.updateSubcategory);
router.delete('/subcategories/:id', AdminauthMiddleware, subcategoryController.deleteSubcategory);

//routing for products
router.get('/products', combinedAuthMiddleware, productController.getProducts);
router.get('/products/:id', combinedAuthMiddleware, productController.getProduct);
router.post('/products', AdminauthMiddleware, upload.array('images', 4), productController.createProduct);
router.put('/products/:id', AdminauthMiddleware, upload.array('images', 4), productController.updateProduct);
router.delete('/products/:id', AdminauthMiddleware, productController.deleteProduct);


// Create a new address
router.post('/createAddress', combinedAuthMiddleware, addressController.createAddress);
router.get('/getAddresses', combinedAuthMiddleware, addressController.getAddresses);
router.get('/getAddressById/:index', combinedAuthMiddleware, addressController.getAddressById);
router.put('/updateAddress/:index', combinedAuthMiddleware, addressController.updateAddress);
router.delete('/deleteAddress/:index', combinedAuthMiddleware, addressController.deleteAddress);


// router.get('/admin', adminController.getAdmins);
// router.get('/admin/:username', adminController.getAdmin);
router.post('/admin', adminController.createAdmin);
router.put('/admin/:username', adminController.updateAdmin);
// router.delete('/admin/:username', adminController.deleteAdmin);


router.post('/admin/login', authController.Adminlogin);
router.post('/user/login', authController.userlogin)


//routing for roles
router.post('/postRole', AdminauthMiddleware, roleController.createdRoles);
router.get('/getRoles',AdminauthMiddleware, roleController.getAllRoles);
router.get('/getRole/:id',AdminauthMiddleware, roleController.getRoleById);
router.put('/updateRole/:id',AdminauthMiddleware, roleController.updateRole);
router.delete('/deleteRole/:id', AdminauthMiddleware, roleController.deleteRole)


//routing for order
router.post('/createOrder', userAuthMiddleware, orderController.createOrder);
router.get('/getOrders', combinedAuthMiddleware, orderController.getOrders);
router.get('/getOrderById/:orderId', combinedAuthMiddleware, orderController.getOrderById);
router.put('/updateOrder/:orderId', combinedAuthMiddleware, orderController.updateOrder);
// router.delete('/deleteOrder/:id', orderController.deleteOrder);

router.post('/uploadphoto', uploadPhotoController.uploadPhoto);
router.get('/getPhotos/:orderId', uploadPhotoController.getPhotos);


router.post('/pay', userAuthMiddleware, paymentController.PaymentInitiate);
router.post('/phonepe/webhook', paymentController.CallbackWebhook);
router.post('/status/:merchantTransactionId', userAuthMiddleware, paymentController.CheckPaymentStatus);


module.exports = router;
