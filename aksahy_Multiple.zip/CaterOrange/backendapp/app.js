// app.js
const express = require('express');
const bodyParser = require('body-parser');
const userRoutes = require('./routes/userRoutes');
const { requestLogger, errorLogger } = require('./middleware/loggingMiddleware');
const sequelize = require('./Db/index');
const cors = require('cors');

const app = express();

app.use(bodyParser.json());
app.use(cors());
app.use(requestLogger);

app.use('/api', userRoutes);

// Error handling middleware
app.use(errorLogger);

const PORT = process.env.PORT || 9000;

sequelize.sync({ force: false }).then(() => {
    app.listen(PORT, () => {
        console.log(`Server is running on port ${PORT}`);
    });
});
