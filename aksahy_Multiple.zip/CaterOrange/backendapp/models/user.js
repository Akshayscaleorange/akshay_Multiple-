// models/user.js
'use strict';

const { DataTypes } = require('sequelize');
const sequelize = require('../Db');
const Roles = require('./roles');
const jwt = require('jsonwebtoken');
// const Address = require('./address')

const User = sequelize.define('Users', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    firstname: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
            notEmpty: true, 
            len: [0, 20] 
        }
    },
    lastname: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
            notEmpty: true, 
            len: [0, 20] 
        }
    },
    email: {
        type: DataTypes.STRING(30),
        allowNull: false,
        unique: true,
        validate: {
            isEmail: {
                msg: "Must be a valid email address",
            }
        }
    },
    password: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "Password is required",
                // Only validate notEmpty on create
                args: true,
                msg: 'Password should not be empty',
                when: (instance, options) => options.fields.includes('password')
            }
        }
    },
    confirm_password: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "Confirm password is required",
                // Only validate notEmpty on create
                args: true,
                msg: 'Confirm password should not be empty',
                when: (instance, options) => options.fields.includes('confirm_password')
            }
        }
    },
    // address: {
    //     type: DataTypes.STRING,
    //     allowNull: true,
    // },
    // address_id: {
    //     type: DataTypes.INTEGER,
    //     allowNull: false,
    //     references: {
    //         model: Address,
    //         key: 'id'
    //     },
    // },
    phone_number: {
        type: DataTypes.STRING,
        allowNull: true,
        unique: true, 
        validate: {
            notEmpty: {
                msg: 'Phone number must not be empty'
            },
            len: {
                args: [10, 10], // Ensure the length is exactly 10 characters
                msg: 'Phone number must be exactly 10 digits'
            },
            is: {
                args: /^[0-9]{10}$/, 
                msg: 'Phone number must be a valid 10-digit number'
            }
        }
    },
    pincode: {
        type: DataTypes.INTEGER, // Changed to INTEGER
        allowNull: true,
        validate: {
            notEmpty: true,
        }
    },
    role_id: {
        type: DataTypes.INTEGER,
        references: {
            model: Roles,
            key: 'id'
        },
        allowNull: false,
        defaultValue: 1 
    },
    accesstoken: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
    }
}, {
    timestamps: true,
    createdAt: 'created_at',
    updatedAt: 'updated_at',
    validate: {
        // Custom validation to ensure password and confirm_password match only on creation
        passwordMatch() {
            if (this.password !== this.confirm_password) {
                throw new Error('Password and confirm password do not match');
            }
        }
    }
});

User.prototype.generateAuthToken = function () {
    const token = jwt.sign({ email: this.email, role_id: this.role_id }, 'your_jwt_secret', { expiresIn: '1hr' });
    return token;
};

User.belongsTo(Roles, { foreignKey: 'role_id' });
Roles.hasMany(User, { foreignKey: 'role_id' });

module.exports = User;
