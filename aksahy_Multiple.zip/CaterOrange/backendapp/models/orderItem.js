// 'use strict';

// const { DataTypes } = require('sequelize');
// const sequelize = require('../Db');
// const Order = require('./orders');
// const Product = require('./products');

// const OrderItem = sequelize.define('OrderItem', {
//     id: {
//         type: DataTypes.INTEGER,
//         autoIncrement: true,
//         primaryKey: true,
//     },
//     order_id: {
//         type: DataTypes.INTEGER,
//         allowNull: false,
//         references: {
//             model: Order,
//             key: 'id'
//         },
//     },
//     product_id: {
//         type: DataTypes.INTEGER,
//         allowNull: false,
//         references: {
//             model: Product,
//             key: 'id'
//         },
//     },
//     quantity: {
//         type: DataTypes.INTEGER,
//         allowNull: false,
//     },
//     TotalPrice: {
//         type: DataTypes.DECIMAL(10, 2), // You can adjust the precision and scale as needed
//         allowNull: false,
//     },
//     dates_of_delivery: {
//         type: DataTypes.JSON, // Use JSON to store array of dates
//         allowNull: false,
//         validate: {
//             isArray(value) {
//                 if (!Array.isArray(value)) {
//                     throw new Error('Dates of delivery must be an array');
//                 }
//                 for (const date of value) {
//                     if (isNaN(Date.parse(date))) {
//                         throw new Error('Each date in the dates of delivery array must be a valid date');
//                     }
//                 }
//             }
//         }
//     },
// }, {
//     timestamps: true,
//     createdAt: 'created_at',
//     updatedAt: 'updated_at'
// });

// Order.hasMany(OrderItem, { foreignKey: 'order_id' });
// OrderItem.belongsTo(Order, { foreignKey: 'order_id' });

// Product.hasMany(OrderItem, { foreignKey: 'product_id' });
// OrderItem.belongsTo(Product, { foreignKey: 'product_id' });

// module.exports = OrderItem;






'use strict';

const { DataTypes } = require('sequelize');
const sequelize = require('../Db');
const Order = require('./orders');
const Product = require('./products');

const OrderItem = sequelize.define('OrderItem', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    order_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: Order,
            key: 'id'
        },
    },
    product_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: Product,
            key: 'id'
        },
    },
    ProductName: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    ProductQuantity: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    ProductPrice: {
        type: DataTypes.DECIMAL(10, 2), // Adjust precision and scale as needed
        allowNull: false,
    },
    ProductTotalPrice: {
        type: DataTypes.DECIMAL(10, 2), // You can adjust the precision and scale as needed
        allowNull: false,
    },
    dates_of_delivery: {
        type: DataTypes.JSON, // Use JSON to store array of dates
        allowNull: false,
        validate: {
            isArray(value) {
                if (!Array.isArray(value)) {
                    throw new Error('Dates of delivery must be an array');
                }
                for (const date of value) {
                    if (isNaN(Date.parse(date))) {
                        throw new Error('Each date in the dates of delivery array must be a valid date');
                    }
                }
            }
        }
    },
}, {
    timestamps: true,
    createdAt: 'created_at',
    updatedAt: 'updated_at'
});

Order.hasMany(OrderItem, { foreignKey: 'order_id' });
OrderItem.belongsTo(Order, { foreignKey: 'order_id' });

Product.hasMany(OrderItem, { foreignKey: 'product_id' });
OrderItem.belongsTo(Product, { foreignKey: 'product_id' });

module.exports = OrderItem;
