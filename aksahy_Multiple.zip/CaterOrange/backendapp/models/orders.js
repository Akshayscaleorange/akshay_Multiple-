// 'use strict';

// const { DataTypes } = require('sequelize');
// const sequelize = require('../Db');

// const Order = sequelize.define('Order', {
//     id: {
//         type: DataTypes.INTEGER,
//         autoIncrement: true,
//         primaryKey: true,
//     },
//     user_id: {
//         type: DataTypes.INTEGER,
//         allowNull: false,
//     },
//     firstname: {
//         type: DataTypes.STRING,
//         allowNull: false,
//     },
//     lastname: {
//         type: DataTypes.STRING,
//         allowNull: false,
//     },
//     email: {
//         type: DataTypes.STRING,
//         allowNull: false,
//     },
//     address_id: {
//         type: DataTypes.INTEGER,
//         allowNull: false,
//     },
//     contact_number: {
//         type: DataTypes.STRING,
//         allowNull: false,
//     },
//     full_address: {
//         type: DataTypes.STRING,
//         allowNull: false,
//     },
//     pincode: {
//         type: DataTypes.STRING,
//         allowNull: false,
//     },
//     latitude: {
//         type: DataTypes.FLOAT,
//         allowNull: false,
//     },
//     longitude: {
//         type: DataTypes.FLOAT,
//         allowNull: false,
//     },
//     state: {
//         type: DataTypes.STRING,
//         allowNull: false,
//     },
//     nearby_location: {
//         type: DataTypes.STRING,
//         allowNull: false,
//     },
//     item_details: {
//         type: DataTypes.JSON,
//         allowNull: false,
//     },
//     payment_id: {
//         type: DataTypes.INTEGER,
//         allowNull: false,
//     },
//     payment_status: {
//         type: DataTypes.STRING,
//         allowNull: false,
//     },
//     media: {
//         type: DataTypes.ARRAY(DataTypes.STRING),
//         allowNull: true,
//     },
//     created_at: {
//         type: DataTypes.DATE,
//         allowNull: false,
//         defaultValue: DataTypes.NOW,
//     },
//     updated_at: {
//         type: DataTypes.DATE,
//         allowNull: false,
//         defaultValue: DataTypes.NOW,
//     },
// }, {
//     timestamps: true,
//     createdAt: 'created_at',
//     updatedAt: 'updated_at'
// });

// module.exports = Order;








'use strict';

const { DataTypes } = require('sequelize');
const sequelize = require('../Db');
const User = require('./user');
const Address = require('./address');
const Payment = require('./payment')

const Order = sequelize.define('Order', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    user_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: User,
            key: 'id'
        },
    },
    address_details: {
        type: DataTypes.JSON,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: 'Address details must not be empty'
            }
        }
    },
    payment_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: Payment,
            key: 'id'
        },
    },
    merchantTransactionId: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    payment_status: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    TotalPrice: {
        type: DataTypes.DECIMAL(10, 2), // You can adjust the precision and scale as needed
        allowNull: false,
    },
}, {
    timestamps: true,
    createdAt: 'created_at',
    updatedAt: 'updated_at'
});

User.hasMany(Order, { foreignKey: 'user_id' });
Order.belongsTo(User, { foreignKey: 'user_id' });

module.exports = Order;


