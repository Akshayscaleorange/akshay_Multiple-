// 'use strict';

// const { DataTypes } = require('sequelize');
// const sequelize = require('../Db');
// const User = require('./user');

// const Address = sequelize.define('Address', {
//     id: {
//         type: DataTypes.INTEGER,
//         autoIncrement: true,
//         primaryKey: true,
//     },
//     user_id: {
//         type: DataTypes.INTEGER,
//         allowNull: false,
//         references: {
//             model: User,
//             key: 'id'
//         },
//     },
//     full_address: {
//         type: DataTypes.STRING,
//         allowNull: false,
//         validate: {
//             notEmpty: {
//                 msg: 'Full address must not be empty'
//             },
//             len: {
//                 args: [1, 100],
//                 msg: 'Full address must be between 1 and 100 characters long'
//             }
//         }
//     },
//     pincode: {
//         type: DataTypes.STRING,
//         allowNull: false,
//         validate: {
//             notEmpty: {
//                 msg: 'Pincode must not be empty'
//             }
//         }
//     },
//     latitude: {
//         type: DataTypes.FLOAT,
//         allowNull: false,
//         validate: {
//             notNull: {
//                 msg: 'Latitude must not be null'
//             },
//             isFloat: {
//                 msg: 'Latitude must be a valid float value'
//             }
//         }
//     },
//     longitude: {
//         type: DataTypes.FLOAT,
//         allowNull: false,
//         validate: {
//             notNull: {
//                 msg: 'Longitude must not be null'
//             },
//             isFloat: {
//                 msg: 'Longitude must be a valid float value'
//             }
//         }
//     },
//     contact_number: {
//         type: DataTypes.STRING,
//         allowNull: false,
//         validate: {
//             notEmpty: {
//                 msg: 'Contact number must not be empty'
//             },
//             is: {
//                 args: /^[0-9]{10}$/,
//                 msg: 'Contact number must be a valid 10-digit number'
//             }
//         }
//     },
//     state: {
//         type: DataTypes.STRING,
//         allowNull: false,
//         validate: {
//             notEmpty: {
//                 msg: 'State must not be empty'
//             }
//         }
//     },
//     nearby_location: {
//         type: DataTypes.STRING,
//         allowNull: false,
//         validate: {
//             notEmpty: {
//                 msg: 'Nearby location must not be empty'
//             }
//         }
//     },
//     created_at: {
//         type: DataTypes.DATE,
//         allowNull: false,
//         defaultValue: DataTypes.NOW,
//     },
//     updated_at: {
//         type: DataTypes.DATE,
//         allowNull: false,
//         defaultValue: DataTypes.NOW,
//     },
// }, {
//     timestamps: true,
//     createdAt: 'created_at',
//     updatedAt: 'updated_at'
// });

// User.hasMany(Address, { foreignKey: 'user_id' });
// Address.belongsTo(User, { foreignKey: 'user_id' });

// module.exports = Address;






// 'use strict';

// const { DataTypes } = require('sequelize');
// const sequelize = require('../Db');
// const User = require('./user');

// const Address = sequelize.define('Address', {
//     id: {
//         type: DataTypes.INTEGER,
//         autoIncrement: true,
//         primaryKey: true,
//     },
//     user_id: {
//         type: DataTypes.INTEGER,
//         allowNull: false,
//         references: {
//             model: User,
//             key: 'id'
//         },
//     },
//     addresses: {
//         type: DataTypes.JSON,
//         allowNull: false,
//         defaultValue: [],
//         get() {
//             const rawValue = this.getDataValue('addresses');
//             return Array.isArray(rawValue) ? rawValue : JSON.parse(rawValue || '[]');
//         },
//         set(value) {
//             this.setDataValue('addresses', JSON.stringify(value));
//         },
//         validate: {
//             isValidAddresses(value) {
//                 if (!Array.isArray(value)) {
//                     throw new Error('Addresses must be an array');
//                 }
//                 for (const addr of value) {
//                     if (typeof addr !== 'object') {
//                         throw new Error('Each address must be an object');
//                     }
//                     if (!addr.full_address || !addr.pincode || !addr.latitude || !addr.longitude ||
//                         !addr.contact_number || !addr.state || !addr.nearby_location) {
//                         throw new Error('Each address must have all required fields');
//                     }
//                 }
//             }
//         }
//     },
//     created_at: {
//         type: DataTypes.DATE,
//         allowNull: false,
//         defaultValue: DataTypes.NOW,
//     },
//     updated_at: {
//         type: DataTypes.DATE,
//         allowNull: false,
//         defaultValue: DataTypes.NOW,
//     },
// }, {
//     timestamps: true,
//     createdAt: 'created_at',
//     updatedAt: 'updated_at'
// });

// User.hasMany(Address, { foreignKey: 'user_id' });
// Address.belongsTo(User, { foreignKey: 'user_id' });

// module.exports = Address;







'use strict';

const { DataTypes } = require('sequelize');
const sequelize = require('../Db');
const User = require('./user');

const Address = sequelize.define('Address', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    user_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: User,
            key: 'id'
        },
    },
    addresses: {
        type: DataTypes.JSON,
        allowNull: false,
        defaultValue: [],
        validate: {
            isValidAddresses(value) {
                if (!Array.isArray(value)) {
                    throw new Error('Addresses must be provided as an array');
                }
                value.forEach(address => {
                    if (!address.full_address || address.full_address.length < 1 || address.full_address.length > 100) {
                        throw new Error('Full address must be between 1 and 100 characters long');
                    }
                    if (!address.pincode || address.pincode.length < 1) {
                        throw new Error('Pincode must not be empty');
                    }
                    if (address.latitude === null || address.latitude === undefined || isNaN(address.latitude)) {
                        throw new Error('Latitude must be a valid float value');
                    }
                    if (address.longitude === null || address.longitude === undefined || isNaN(address.longitude)) {
                        throw new Error('Longitude must be a valid float value');
                    }
                    if (!address.contact_number || !/^[0-9]{10}$/.test(address.contact_number)) {
                        throw new Error('Contact number must be a valid 10-digit number');
                    }
                    if (!address.state || address.state.length < 1) {
                        throw new Error('State must not be empty');
                    }
                    if (!address.nearby_location || address.nearby_location.length < 1) {
                        throw new Error('Nearby location must not be empty');
                    }
                });
            }
        }
    },
}, {
    timestamps: false, // Disable timestamps for this model
});

User.hasOne(Address, { foreignKey: 'user_id' });
Address.belongsTo(User, { foreignKey: 'user_id' });

module.exports = Address;
