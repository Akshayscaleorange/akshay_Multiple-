'use strict';

const { DataTypes } = require('sequelize');
const sequelize = require('../Db');
const User = require('./user');
const Order =require('./orders')

const Payment = sequelize.define('Payment', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    userId: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: User,
            key: 'id'
        },
        field: 'user_id'
    },
    merchantId: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    merchantTransactionId: {
        type: DataTypes.STRING,
        allowNull: true,
        // unique: true
    },
    transactionId: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    amount: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: true,
    },
    state: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    responseCode: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    paymentType: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    pgTransactionId: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    pgServiceTransactionId: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    bankTransactionId: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    bankId: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    arn: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    status: {
        type: DataTypes.STRING,
        allowNull: true,
    }
}, {
    timestamps: true,
    createdAt: 'created_at',
    updatedAt: 'updated_at'
});

User.hasMany(Payment, { foreignKey: 'userId' });
Payment.belongsTo(User, { foreignKey: 'userId' });

// Order.hasMany(Payment, { foreignKey: 'orderId' });
// Payment.belongsTo(Order, { foreignKey: 'orderId' });

module.exports = Payment;
