// loggingMiddleware.js
const logger = require('../controllers/logger');

const requestLogger = (req, res, next) => {
    logger.info(`Incoming request: ${req.method} ${req.url}`);
    next();
};

const errorLogger = (err, req, res, next) => {
    logger.error(`Error occurred: ${err.message}`);
    res.status(500).json({
        status: 'error',
        message: 'Internal server error',
    });
};

module.exports = { requestLogger, errorLogger };
