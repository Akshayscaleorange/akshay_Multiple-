'use strict';

const axios = require('axios');
const sha256 = require('sha256');
const crypto = require('crypto');
const Order = require('../models/orders');
const Payment = require('../models/payment')

const PaymentInitiate = (req, res) => {
    const payEndpoint = "/pg/v1/pay";
    const { amount, phonenumber, merchantTransactionId } = req.body;
    const user = req.user;
    const salt_key = process.env.SALT_KEY;
    const salt_Index = process.env.SALT_INDEX;
    const amountInPaise = amount * 100;

    const payload = {
        "merchantId": process.env.MERCHANT_ID,
        "merchantTransactionId": merchantTransactionId,
        "merchantUserId": user.id,
        // "merchantOrderId": orderId,
        "amount": amountInPaise,
        "redirectUrl": `http://localhost:3001/OrderConfirmation`,
        "redirectMode": "REDIRECT",
        "callbackUrl": "http://localhost:9000/api/phonepe/webhook",
        "mobileNumber": phonenumber,
        "paymentInstrument": {
            "type": "PAY_PAGE"
        }
    };

    const bufferObj = Buffer.from(JSON.stringify(payload), "utf8");
    const base64EncodedPayload = bufferObj.toString("base64");
    const xVerify = sha256(base64EncodedPayload + payEndpoint + salt_key) + "###" + salt_Index;

    const options = {
        method: 'post',
        url: `${process.env.PHONE_PE_HOST_URL}${payEndpoint}`,
        headers: {
            'Content-Type': 'application/json',
            "X-VERIFY": xVerify
        },
        data: {
            "request": base64EncodedPayload,
        }
    };

    axios.request(options)
        .then(function (response) {
            res.send(response.data);
        })
        .catch(function (error) {
            console.error(error);
            res.status(500).send('Internal Server Error');
        });
};


const CallbackWebhook = async (req, res) => {
    try {
        const callbackHeaders = req.headers;
        const base64response = req.body.response;
        const xVerifyHeader = callbackHeaders['x-verify'];
        const decodedResponse = Buffer.from(base64response, 'base64').toString('utf8');
        const parsedResponse = JSON.parse(decodedResponse);
        const merchantTransactionId = parsedResponse.data.merchantTransactionId;
        const code = parsedResponse.code;

        const payload = base64response + process.env.SALT_KEY;
        const computedChecksum = crypto.createHash('sha256').update(payload).digest('hex') + '###' + process.env.SALT_INDEX;

        if (xVerifyHeader !== computedChecksum) {
            return res.status(400).send('Checksum validation failed');
        }

        // const updatedOrder = await Order.update(
        //     { payment_status: code },
        //     { where: { merchantTransactionId } }
        // );

        // if (!updatedOrder[0]) {
        //     return res.status(404).send(`Order not found for merchantTransactionId: ${merchantTransactionId}`);
        // }

        res.status(200).send(`Order updated successfully: ${merchantTransactionId}`);
    } catch (error) {
        console.error('Error processing webhook:', error);
        res.status(500).send('Internal server error');
    }
};

const CheckPaymentStatus = async (req, res) => {
    const { merchantTransactionId } = req.params;
    console.log("merchantTransactionId", merchantTransactionId)
    const merchantId = process.env.MERCHANT_ID;
    // const { userId } = req.params;
    // console.log("userId",userId)
    const user = req.user;
    console.log("user",user)

    if (!merchantTransactionId) {
        return res.status(400).send('merchantTransactionId is required');
    }

    try {
        const endpoint = `/pg/v1/status/${merchantId}/${merchantTransactionId}`;
        const xVerify = sha256(endpoint + process.env.SALT_KEY) + "###" + process.env.SALT_INDEX;

        const options = {
            method: 'get',
            url: `${process.env.PHONE_PE_HOST_URL}${endpoint}`,
            headers: {
                'Content-Type': 'application/json',
                'X-MERCHANT-ID': merchantId,
                'X-VERIFY': xVerify,
            },
        };

        const response = await axios.request(options);
        const paymentStatus = response.data; // Assuming response contains payment status details

        const newPayment = await Payment.create({
            userId: user.id,
            merchantId: paymentStatus.data.merchantId,
            merchantTransactionId: paymentStatus.data.merchantTransactionId,
            transactionId: paymentStatus.data.transactionId,
            amount: paymentStatus.data.amount,
            state: paymentStatus.data.state,
            responseCode: paymentStatus.data.responseCode,
            paymentType: paymentStatus.data.paymentInstrument.type,
            pgTransactionId: paymentStatus.data.paymentInstrument.pgTransactionId,
            pgServiceTransactionId: paymentStatus.data.paymentInstrument.pgServiceTransactionId,
            bankTransactionId: paymentStatus.data.paymentInstrument.bankTransactionId,
            bankId: paymentStatus.data.paymentInstrument.bankId,
            arn: paymentStatus.data.paymentInstrument.arn,
            status: paymentStatus.data.state,
        });

        if (!newPayment) {
            return res.status(500).send('Failed to create new payment record');
        }

        const updatedOrder = await Order.update({
            payment_status: paymentStatus.code,
            updated_at: new Date(), // Update the updated_at timestamp
        }, {
            where: { merchantTransactionId }
        });

        if (updatedOrder[0] === 0) {
            return res.status(404).send(`Order record not found for merchantTransactionId: ${merchantTransactionId}`);
        }

        // console.log("response from phonepay",response)
        res.status(200).send('Payment status and Order updated successfully');
    } catch (error) {
        console.error('Error checking payment status:', error);
        res.status(500).send('Internal server error');
    }
};

module.exports = { PaymentInitiate, CallbackWebhook, CheckPaymentStatus }