'use strict';

// Import the Subcategory model
const Subcategory = require('../models/subcategories');
const Product = require('../models/products');
const logger = require('./logger');

// Function to validate input
const containsMaliciousInput = (input) => {
    if (typeof input === 'string') {
        return /[<>'"%;]/.test(input);
    }
    return false;
};

// // Handler to get all subcategories
// exports.getSubcategories = async (req, res) => {
//     try {
//         const subcategories = await Subcategory.findAll();
//         logger.info('Fetched all subcategories');
//         res.json(subcategories);
//     } catch (error) {
//         logger.error(`Error fetching subcategories: ${error.message}`);
//         res.status(500).json({ error: error.message });
//     }
// };




// Handler to get all subcategories with pagination
exports.getSubcategories = async (req, res) => {
    try {
        const page = parseInt(req.query.page, 10) || 1; // Default to page 1 if not provided
        const pageSize = parseInt(req.query.pageSize, 10) || 10; // Default to 10 items per page if not provided

        const offset = (page - 1) * pageSize;
        const limit = pageSize;

        const { count, rows } = await Subcategory.findAndCountAll({
            offset,
            limit
        });

        logger.info(`Fetched ${rows.length} subcategories`);
        res.json({
            totalItems: count,
            totalPages: Math.ceil(count / pageSize),
            currentPage: page,
            subcategories: rows
        });
    } catch (error) {
        logger.error(`Error fetching subcategories: ${error.message}`);
        res.status(500).json({ error: error.message });
    }
};


// Handler to get a specific subcategory by its ID
exports.getSubcategory = async (req, res) => {
    try {
        const subcategoryId = req.params.id;
        if (containsMaliciousInput(subcategoryId)) {
            return res.status(400).json({ error: 'Invalid subcategory ID' });
        }

        const subcategory = await Subcategory.findByPk(subcategoryId);
        if (subcategory) {
            logger.info(`Fetched subcategory by ID: ${subcategoryId}`);
            res.json(subcategory);
        } else {
            logger.warn(`Subcategory not found for ID: ${subcategoryId}`);
            res.status(404).json({ error: 'Subcategory not found' });
        }
    } catch (error) {
        logger.error(`Error fetching subcategory: ${error.message}`);
        res.status(500).json({ error: 'Internal server error' });
    }
};

// Handler to create a new subcategory
exports.createSubcategory = async (req, res) => {
    try {
        const { category_id, subcategory_name } = req.body;

        // Validate input
        if (containsMaliciousInput(subcategory_name) || containsMaliciousInput(category_id.toString())) {
            return res.status(400).json({ error: 'Invalid input' });
        }

        const newSubcategory = await Subcategory.create({
            category_id,
            subcategory_name
        });

        logger.info(`Created subcategory: ${newSubcategory.subcategory_name}`);
        res.status(201).json(newSubcategory);
    } catch (error) {
        logger.error(`Error creating subcategory: ${error.message}`);
        res.status(500).json({ error: 'Internal server error' });
    }
};

// Handler to update an existing subcategory by its ID
exports.updateSubcategory = async (req, res) => {
    try {
        const subcategoryId = req.params.id;
        const { category_id, subcategory_name } = req.body;

        if (containsMaliciousInput(subcategoryId) || containsMaliciousInput(subcategory_name) || containsMaliciousInput(category_id.toString())) {
            return res.status(400).json({ error: 'Invalid input' });
        }

        const updateData = {
            category_id,
            subcategory_name
        };

        const [updated] = await Subcategory.update(updateData, { where: { id: subcategoryId } });

        if (updated) {
            const updatedSubcategory = await Subcategory.findByPk(subcategoryId);
            logger.info(`Updated subcategory with ID ${subcategoryId}`);
            res.status(200).json(updatedSubcategory);
        } else {
            logger.warn(`Subcategory not found for update: ID ${subcategoryId}`);
            res.status(404).json({ error: 'Subcategory not found' });
        }
    } catch (error) {
        logger.error(`Error updating subcategory: ${error.message}`);
        res.status(500).json({ error: 'Internal server error' });
    }
};

// Handler to delete a subcategory by its ID
exports.deleteSubcategory = async (req, res) => {
    try {
        const subcategoryId = req.params.id;
        if (containsMaliciousInput(subcategoryId)) {
            return res.status(400).json({ error: 'Invalid subcategory ID' });
        }

        const products = await Product.findAll({ where: { subcategory_id: subcategoryId } });
        if (products.length > 0) {
            return res.status(400).json({ error: 'Subcategory has dependent products. Please delete them first.' });
        }

        const deleted = await Subcategory.destroy({ where: { id: subcategoryId } });
        if (deleted) {
            logger.info(`Deleted subcategory with ID ${subcategoryId}`);
            res.status(204).json();
        } else {
            logger.warn(`Subcategory not found for deletion: ID ${subcategoryId}`);
            res.status(404).json({ error: 'Subcategory not found' });
        }
    } catch (error) {
        logger.error(`Error deleting subcategory: ${error.message}`);
        res.status(500).json({ error: 'Internal server error' });
    }
};