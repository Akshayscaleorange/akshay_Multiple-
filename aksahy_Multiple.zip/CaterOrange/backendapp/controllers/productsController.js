'use strict';

const Product = require('../models/products');
const logger = require('./logger');

// Function to check for potentially malicious input
const containsMaliciousInput = (input) => {
    if (typeof input === 'string') {
        return /\{.*\}/.test(input) || /[<>'"%;]/.test(input); // Add other characters as needed
    }
    return false;
};

// exports.getProducts = async (req, res) => {
//     try {
//         const products = await Product.findAll();
//         logger.info(`Fetched ${products.length} products`);
//         res.json(products);
//     } catch (error) {
//         logger.error(`Error fetching products: ${error.message}`);
//         res.status(500).json({ error: 'Internal server error' });
//     }
// };

exports.getProduct = async (req, res) => {
    try {
        const productId = req.params.id;
        if (containsMaliciousInput(productId)) {
            logger.warn('Invalid product ID detected in getProduct');
            return res.status(400).json({ error: 'Invalid product ID' });
        }

        const product = await Product.findByPk(productId);
        if (product) {
            logger.info(`Product fetched successfully: Product ID ${productId}`);
            res.json(product);
        } else {
            logger.warn(`Product not found: Product ID ${productId}`);
            res.status(404).json({ error: 'Product not found' });
        }
    } catch (error) {
        logger.error(`Error fetching product: ${error.message}`);
        res.status(500).json({ error: 'Internal server error' });
    }
};




exports.getProducts = async (req, res) => {
    try {
        const page = parseInt(req.query.page, 10) || 1; // Default to page 1 if not provided
        const pageSize = parseInt(req.query.pageSize, 10) || 10; // Default to 10 items per page if not provided

        const offset = (page - 1) * pageSize;
        const limit = pageSize;

        const { count, rows } = await Product.findAndCountAll({
            offset,
            limit
        });

        logger.info(`Fetched ${rows.length} products`);
        res.json({
            totalItems: count,
            totalPages: Math.ceil(count / pageSize),
            currentPage: page,
            products: rows
        });
    } catch (error) {
        logger.error(`Error fetching products: ${error.message}`);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.createProduct = async (req, res) => {
    try {
        const { category_id, subcategory_id, product_name, quantity, coupon_id, description, price } = req.body;
        const images = req.files ? req.files.map(file => file.buffer.toString('base64')) : [];

        // Validate input
        if (containsMaliciousInput(product_name) || containsMaliciousInput(description) || containsMaliciousInput(coupon_id)) {
            logger.warn('Invalid input detected in createProduct');
            return res.status(400).json({ error: 'Invalid input' });
        }

        const newProduct = await Product.create({
            category_id,
            subcategory_id,
            product_name,
            quantity,
            price,
            images,
            coupon_id,
            description
        });

        logger.info(`Product created successfully: Product ID ${newProduct.id}`);
        res.status(201).json(newProduct);
    } catch (error) {
        logger.error(`Error creating product: ${error.message}`);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.updateProduct = async (req, res) => {
    try {
        const { category_id, subcategory_id, product_name, quantity, price, coupon_id, description } = req.body;
        let images;
        if (req.files && req.files.length > 0) {
            images = req.files.map(file => file.buffer.toString('base64'));
        }

        // Validate input
        if (containsMaliciousInput(product_name) || containsMaliciousInput(description) || containsMaliciousInput(coupon_id)) {
            logger.warn('Invalid input detected in updateProduct');
            return res.status(400).json({ error: 'Invalid input' });
        }

        const updateData = {
            category_id,
            subcategory_id,
            product_name,
            quantity,
            price,
            coupon_id,
            description
        };

        // Conditionally add images to the update data
        if (images) {
            updateData.images = images;
        }

        const productId = req.params.id;
        if (containsMaliciousInput(productId)) {
            logger.warn('Invalid product ID detected in updateProduct');
            return res.status(400).json({ error: 'Invalid product ID' });
        }

        const [updated] = await Product.update(updateData, { where: { id: productId } });

        if (updated) {
            const updatedProduct = await Product.findByPk(productId);
            logger.info(`Product updated successfully: Product ID ${productId}`);
            res.status(200).json(updatedProduct);
        } else {
            logger.warn(`Product not found: Product ID ${productId}`);
            res.status(404).json({ error: 'Product not found' });
        }
    } catch (error) {
        logger.error(`Error updating product: ${error.message}`);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.deleteProduct = async (req, res) => {
    try {
        const productId = req.params.id;
        if (containsMaliciousInput(productId)) {
            logger.warn('Invalid product ID detected in deleteProduct');
            return res.status(400).json({ error: 'Invalid product ID' });
        }

        const deleted = await Product.destroy({ where: { id: productId } });
        if (deleted) {
            logger.info(`Product deleted successfully: Product ID ${productId}`);
            res.status(204).json();
        } else {
            logger.warn(`Product not found: Product ID ${productId}`);
            res.status(404).json({ error: 'Product not found' });
        }
    } catch (error) {
        logger.error(`Error deleting product: ${error.message}`);
        res.status(500).json({ error: 'Internal server error' });
    }
};