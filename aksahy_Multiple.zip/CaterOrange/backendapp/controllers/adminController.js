// 'use strict';

// const Admin = require('../models/admin');

// const containsMaliciousInput = (input) => {
//     if (typeof input === 'string') {
//         return /\{.*\}/.test(input) || /[<>'"%;]/.test(input); // Add other characters as needed
//     }
//     return false;
// };

// exports.getAdmins = async (req, res) => {
//     try {
//         const admins = await Admin.findAll();
//         res.json(admins);
//     } catch (error) {
//         res.status(500).json({ error: error.message });
//     }
// };

// exports.getAdmin = async (req, res) => {
//     try {

//         const username = req.params.username;
//         // Check for potentially malicious input
//         if (containsMaliciousInput(username)) {
//             return res.status(400).json({ error: 'Invalid username' });
//         }

//         const admin = await Admin.findByPk(username);
//         if (admin) {
//             res.json(admin);
//         } else {
//             res.status(404).json({ error: 'Admin not found' });
//         }
//     } catch (error) {
//         res.status(500).json({ error: error.message });
//     }
// };

// exports.createAdmin = async (req, res) => {
//     try {

//         const { username, password } = req.body;

//         // Validate input
//         if (containsMaliciousInput(username) || containsMaliciousInput(password)) {
//             return res.status(400).json({ error: 'Invalid input' });
//         }
        
//         // Check if the username already exists
//         const existingAdmin = await Admin.findOne({ where: { username: req.body.username } });
//         if (existingAdmin) {
//             return res.status(400).json({ error: 'Username already exists' });
//         }

//         // If username doesn't exist, proceed with creating the new admin
//         const newAdmin = await Admin.create(req.body);
//         res.status(201).json(newAdmin);
//     } catch (error) {
//         res.status(500).json({ error: error.message });
//     }
// };


// exports.updateAdmin = async (req, res) => {
//     try {
//         const username = req.params.username;

//         // Validate input
//         if (containsMaliciousInput(username) || containsMaliciousInput(updatedData.username) || containsMaliciousInput(updatedData.password)) {
//             return res.status(400).json({ error: 'Invalid input' });
//         }

//         const [updated] = await Admin.update(req.body, { where: { username: req.params.username } });
//         if (updated) {
//             const updatedAdmin = await Admin.findByPk(req.params.username);
//             res.status(200).json(updatedAdmin);
//         } else {
//             res.status(404).json({ error: 'Admin not found' });
//         }
//     } catch (error) {
//         res.status(500).json({ error: error.message });
//     }
// };

// exports.deleteAdmin = async (req, res) => {
//     try {
//         const username = req.params.username;

//         // Check for potentially malicious input
//         if (containsMaliciousInput(username)) {
//             return res.status(400).json({ error: 'Invalid username' });
//         }

//         const deleted = await Admin.destroy({ where: { username: req.params.username } });
//         if (deleted) {
//             res.status(204).json();
//         } else {
//             res.status(404).json({ error: 'Admin not found' });
//         }
//     } catch (error) {
//         res.status(500).json({ error: error.message });
//     }
// };







'use strict';

const Admin = require('../models/admin');
const bcrypt = require('bcryptjs');

// Function to check for curly braces or any other potentially malicious input
const containsMaliciousInput = (input) => {
    if (typeof input === 'string') {
        return /\{.*\}/.test(input) || /[<>'"%;]/.test(input); // Add other characters as needed
    }
    return false;
};

exports.getAdmins = async (req, res) => {
    try {
        const admins = await Admin.findAll();
        logger.info('Fetched all admins');
        res.json(admins);
    } catch (error) {
        logger.error(`Error fetching admins: ${error.message}`);
        res.status(500).json({ error: error.message });
    }
};

exports.getAdmin = async (req, res) => {
    try {
        const username = req.params.username;

        // Check for potentially malicious input
        if (containsMaliciousInput(username)) {
            logger.warn('Invalid username');
            return res.status(400).json({ error: 'Invalid username' });
        }

        const admin = await Admin.findByPk(username);
        if (admin) {
            logger.info(`Fetched admin with username: ${username}`);
            res.json(admin);
        } else {
            logger.warn(`Admin not found with username: ${username}`);
            res.status(404).json({ error: 'Admin not found' });
        }
    } catch (error) {
        logger.error(`Error fetching admin: ${error.message}`);
        res.status(500).json({ error: error.message });
    }
};

exports.createAdmin = async (req, res) => {
    try {
        const { username, password } = req.body;

        // Validate input
        if (containsMaliciousInput(username) || containsMaliciousInput(password)) {
            logger.warn('Invalid input for creating admin');
            return res.status(400).json({ error: 'Invalid input' });
        }

        // Check if the username already exists
        const existingAdmin = await Admin.findOne({ where: { username } });
        if (existingAdmin) {
            logger.warn('Username already exists');
            return res.status(400).json({ error: 'Username already exists' });
        }

        // Hash the password
        const hashedPassword = await bcrypt.hash(password, 8);

        // Create the new admin with hashed password
        const newAdmin = await Admin.create({ username, password: hashedPassword });
        logger.info(`Admin created with username: ${username}`);
        res.status(201).json(newAdmin);
    } catch (error) {
        logger.error(`Error creating admin: ${error.message}`);
        res.status(500).json({ error: error.message });
    }
};

exports.updateAdmin = async (req, res) => {
    try {
        const username = req.params.username;
        const { password, ...updatedData } = req.body;

        // Validate input
        if (containsMaliciousInput(username) || containsMaliciousInput(updatedData.username)) {
            logger.warn('Invalid input for updating admin');
            return res.status(400).json({ error: 'Invalid input' });
        }

        // If password is provided, hash it
        if (password) {
            if (containsMaliciousInput(password)) {
                logger.warn('Invalid password input');
                return res.status(400).json({ error: 'Invalid input' });
            }
            const hashedPassword = await bcrypt.hash(password, 8);
            updatedData.password = hashedPassword;
        }

        const [updated] = await Admin.update(updatedData, { where: { username } });
        if (updated) {
            const updatedAdmin = await Admin.findByPk(username);
            logger.info(`Admin updated with username: ${username}`);
            res.status(200).json(updatedAdmin);
        } else {
            logger.warn(`Admin not found for updating with username: ${username}`);
            res.status(404).json({ error: 'Admin not found' });
        }
    } catch (error) {
        logger.error(`Error updating admin: ${error.message}`);
        res.status(500).json({ error: error.message });
    }
};

exports.deleteAdmin = async (req, res) => {
    try {
        const username = req.params.username;

        // Check for potentially malicious input
        if (containsMaliciousInput(username)) {
            logger.warn('Invalid username input for deletion');
            return res.status(400).json({ error: 'Invalid username' });
        }

        const deleted = await Admin.destroy({ where: { username } });
        if (deleted) {
            logger.info(`Admin deleted with username: ${username}`);
            res.status(204).json();
        } else {
            logger.warn(`Admin not found for deletion with username: ${username}`);
            res.status(404).json({ error: 'Admin not found' });
        }
    } catch (error) {
        logger.error(`Error deleting admin: ${error.message}`);
        res.status(500).json({ error: error.message });
    }
};