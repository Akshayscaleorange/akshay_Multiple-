'use strict';

const Address = require('../models/address');
const User = require('../models/user');
const logger = require('./logger');



// Function to check for curly braces or any other potentially malicious input
const containsMaliciousInput = (input) => {
    if (typeof input === 'string') {
        return /\{.*\}/.test(input) || /[<>'"%;]/.test(input); // Add other characters as needed
    }
    return false;
};


// Create a new address
// exports.createAddress = async (req, res) => {
//     try {
//         const user = req.user; // Extract user from request
//         const address = await Address.create({
//             ...req.body,
//             user_id: user.id // Associate address with the logged-in user
//         });
//         res.status(201).json(address);
//     } catch (error) {
//         res.status(400).json({ error: error.message });
//     }
// };

// Create a new address for a user

// Get all addresses for the logged-in user
// exports.getAddresses = async (req, res) => {
//     try {
//         const user = req.user; // Extract user from request
//         const addresses = await Address.findAll({ where: { user_id: user.id } });
//         res.status(200).json(addresses);
//     } catch (error) {
//         res.status(500).json({ error: error.message });
//     }
// };

// // Get a specific address by ID for the logged-in user
// exports.getAddressById = async (req, res) => {
//     try {
//         const user = req.user; // Extract user from request
//         const address = await Address.findOne({
//             where: { id: req.params.id, user_id: user.id }
//         });
//         if (address) {
//             res.status(200).json(address);
//         } else {
//             res.status(404).json({ error: 'Address not found' });
//         }
//     } catch (error) {
//         res.status(500).json({ error: error.message });
//     }
// };

// // Update an address for the logged-in user
// exports.updateAddress = async (req, res) => {
//     try {
//         const user = req.user; // Extract user from request

//         // Prevent user_id from being updated
//         const { user_id, ...addressData } = req.body;

//         const [updated] = await Address.update(addressData, {
//             where: { id: req.params.id, user_id: user.id }
//         });

//         if (updated) {
//             const updatedAddress = await Address.findOne({
//                 where: { id: req.params.id, user_id: user.id }
//             });
//             res.status(200).json(updatedAddress);
//         } else {
//             res.status(404).json({ error: 'Address not found' });
//         }
//     } catch (error) {
//         res.status(400).json({ error: error.message });
//     }
// };

// // Delete an address for the logged-in user
// exports.deleteAddress = async (req, res) => {
//     try {
//         const user = req.user; // Extract user from request
//         const deleted = await Address.destroy({
//             where: { id: req.params.id, user_id: user.id }
//         });
//         if (deleted) {
//             res.status(204).json();
//         } else {
//             res.status(404).json({ error: 'Address not found' });
//         }
//     } catch (error) {
//         res.status(500).json({ error: error.message });
//     }
// };








// Create or update addresses for a user
exports.createAddress = async (req, res) => {
    try {
        const user = req.user; // Extract user from request
        logger.info(`Creating address for user: ${user.id}`);

        // Validate new address
        const newAddress = req.body;

        // Function to check for curly braces anywhere in the string
        const containsCurlyBraces = (str) => {
            return typeof str === 'string' && /\{.*\}/.test(str);
        };

        // Check if the address object is empty
        if (Object.keys(newAddress).length === 0) {
            logger.warn('Address details must not be empty');
            return res.status(400).json({ error: 'Address details must not be empty' });
        }
        if (containsMaliciousInput(newAddress)) {
            logger.warn('Address contains invalid characters');
            return res.status(400).json({ error: 'Address contains invalid characters' });
        }

        if (containsCurlyBraces(newAddress.full_address) || !newAddress.full_address || newAddress.full_address.length < 1 || newAddress.full_address.length > 100) {
            logger.warn('Invalid full address');
            return res.status(400).json({ error: 'Full address must be between 1 and 100 characters long and must not contain curly braces' });
        }
        if (containsCurlyBraces(newAddress.pincode) || !newAddress.pincode || newAddress.pincode.length < 1) {
            logger.warn('Invalid pincode');
            return res.status(400).json({ error: 'Pincode must not be empty and must not contain curly braces' });
        }
        if (newAddress.latitude === null || newAddress.latitude === undefined || isNaN(newAddress.latitude)) {
            logger.warn('Invalid latitude');
            return res.status(400).json({ error: 'Latitude must be a valid float value' });
        }
        if (newAddress.longitude === null || newAddress.longitude === undefined || isNaN(newAddress.longitude)) {
            logger.warn('Invalid longitude');
            return res.status(400).json({ error: 'Longitude must be a valid float value' });
        }
        if (containsCurlyBraces(newAddress.contact_number) || !newAddress.contact_number || !/^[0-9]{10}$/.test(newAddress.contact_number)) {
            logger.warn('Invalid contact number');
            return res.status(400).json({ error: 'Contact number must be a valid 10-digit number and must not contain curly braces' });
        }
        if (containsCurlyBraces(newAddress.state) || !newAddress.state || newAddress.state.length < 1) {
            logger.warn('Invalid state');
            return res.status(400).json({ error: 'State must not be empty and must not contain curly braces' });
        }
        if (containsCurlyBraces(newAddress.nearby_location) || !newAddress.nearby_location || newAddress.nearby_location.length < 1) {
            logger.warn('Invalid nearby location');
            return res.status(400).json({ error: 'Nearby location must not be empty and must not contain curly braces' });
        }

        // Retrieve the existing addresses for the user
        let addressRecord = await Address.findOne({ where: { user_id: user.id } });

        if (!addressRecord) {
            // If no record exists, create a new one
            addressRecord = await Address.create({
                user_id: user.id,
                addresses: [newAddress]
            });
            logger.info('Created new address record for user');
        } else {
            // Append the new address to the existing addresses array
            const updatedAddresses = [...addressRecord.addresses, newAddress];
            addressRecord.addresses = updatedAddresses;
            await addressRecord.save();
            logger.info('Updated address record for user');
        }

        res.status(200).json(addressRecord);
    } catch (error) {
        logger.error(`Error creating address: ${error.message}`);
        res.status(500).json({ error: error.message });
    }
};

// // Get all addresses for the logged-in user
// exports.getAddresses = async (req, res) => {
//     try {
//         const user = req.user; // Extract user from request
//         logger.info(`Fetching addresses for user: ${user.id}`);
//         const addressRecord = await Address.findOne({ where: { user_id: user.id } });

//         if (addressRecord && !containsMaliciousInput(addressRecord.addresses)) {
//             res.status(200).json(addressRecord.addresses);
//         } else {
//             res.status(404).json({ error: 'Addresses not found' });
//         }
//     } catch (error) {
//         logger.error(`Error fetching addresses: ${error.message}`);
//         res.status(500).json({ error: error.message });
//     }
// };

// // Get a specific address by index for the logged-in user
// exports.getAddressById = async (req, res) => {
//     try {
//         const user = req.user; // Extract user from request
//         const index = req.params.index;
//         logger.info(`Fetching address at index ${index} for user: ${user.id}`);

//         const addressRecord = await Address.findOne({ where: { user_id: user.id } });

//         if (addressRecord && addressRecord.addresses[index] && !containsMaliciousInput(addressRecord.addresses[index])) {
//             res.status(200).json(addressRecord.addresses[index]);
//         } else {
//             res.status(404).json({ error: 'Address not found' });
//         }
//     } catch (error) {
//         logger.error(`Error fetching address: ${error.message}`);
//         res.status(500).json({ error: error.message });
//     }
// };


// Get all addresses for the logged-in user with pagination
exports.getAddresses = async (req, res) => {
    try {
        const user = req.user; // Extract user from request
        const page = parseInt(req.query.page, 10) || 1; // Default to page 1 if not provided
        const pageSize = parseInt(req.query.pageSize, 10) || 10; // Default to 10 items per page if not provided

        logger.info(`Fetching addresses for user: ${user.id}, page: ${page}, pageSize: ${pageSize}`);

        const addressRecord = await Address.findOne({ where: { user_id: user.id } });

        if (addressRecord && !containsMaliciousInput(addressRecord.addresses)) {
            const startIndex = (page - 1) * pageSize;
            const endIndex = startIndex + pageSize;
            const paginatedAddresses = addressRecord.addresses.slice(startIndex, endIndex);

            res.status(200).json({
                total: addressRecord.addresses.length,
                page,
                pageSize,
                addresses: paginatedAddresses
            });
        } else {
            res.status(404).json({ error: 'Addresses not found' });
        }
    } catch (error) {
        logger.error(`Error fetching addresses: ${error.message}`);
        res.status(500).json({ error: error.message });
    }
};



// Get a specific address by index for the logged-in user with pagination support
exports.getAddressById = async (req, res) => {
    try {
        const user = req.user; // Extract user from request
        const page = parseInt(req.query.page, 10) || 1; // Default to page 1 if not provided
        const pageSize = parseInt(req.query.pageSize, 10) || 10; // Default to 10 items per page if not provided
        const index = parseInt(req.params.index, 10);

        logger.info(`Fetching address at index ${index} for user: ${user.id}, page: ${page}, pageSize: ${pageSize}`);

        const addressRecord = await Address.findOne({ where: { user_id: user.id } });

        if (addressRecord && addressRecord.addresses[index] && !containsMaliciousInput(addressRecord.addresses[index])) {
            const startIndex = (page - 1) * pageSize;
            const endIndex = startIndex + pageSize;

            if (index >= startIndex && index < endIndex) {
                res.status(200).json(addressRecord.addresses[index]);
            } else {
                res.status(404).json({ error: 'Address not found in the specified page' });
            }
        } else {
            res.status(404).json({ error: 'Address not found' });
        }
    } catch (error) {
        logger.error(`Error fetching address: ${error.message}`);
        res.status(500).json({ error: error.message });
    }
};




// Update a specific address by index for the logged-in user
exports.updateAddress = async (req, res) => {
    try {
        const user = req.user; // Extract user from request
        const index = parseInt(req.params.index, 10);
        const updatedAddress = req.body;
        logger.info(`Updating address at index ${index} for user: ${user.id}`);

        const userAddress = await Address.findOne({ where: { user_id: user.id } });

        if (userAddress && userAddress.addresses[index] && !containsMaliciousInput(updatedAddress)) {
            // Function to check for curly braces anywhere in the string
            const containsCurlyBraces = (str) => {
                return typeof str === 'string' && /\{|\}/.test(str) && str.startsWith('{') && str.endsWith('}');
            };

            // Check if the address object is empty
            if (Object.keys(updatedAddress).length === 0) {
                logger.warn('Address details must not be empty');
                return res.status(400).json({ error: 'Address details must not be empty' });
            }

            // Validate updated address
            if (containsCurlyBraces(updatedAddress.full_address) || !updatedAddress.full_address || updatedAddress.full_address.length < 1 || updatedAddress.full_address.length > 100) {
                logger.warn('Invalid full address');
                return res.status(400).json({ error: 'Full address must be between 1 and 100 characters long and must not contain curly braces' });
            }
            if (containsCurlyBraces(updatedAddress.pincode) || !updatedAddress.pincode || updatedAddress.pincode.length < 1) {
                logger.warn('Invalid pincode');
                return res.status(400).json({ error: 'Pincode must not be empty and must not contain curly braces' });
            }
            if (updatedAddress.latitude === null || updatedAddress.latitude === undefined || isNaN(updatedAddress.latitude)) {
                logger.warn('Invalid latitude');
                return res.status(400).json({ error: 'Latitude must be a valid float value' });
            }
            if (updatedAddress.longitude === null || updatedAddress.longitude === undefined || isNaN(updatedAddress.longitude)) {
                logger.warn('Invalid longitude');
                return res.status(400).json({ error: 'Longitude must be a valid float value' });
            }
            if (containsCurlyBraces(updatedAddress.contact_number) || !updatedAddress.contact_number || !/^[0-9]{10}$/.test(updatedAddress.contact_number)) {
                logger.warn('Invalid contact number');
                return res.status(400).json({ error: 'Contact number must be a valid 10-digit number and must not contain curly braces' });
            }
            if (containsCurlyBraces(updatedAddress.state) || !updatedAddress.state || updatedAddress.state.length < 1) {
                logger.warn('Invalid state');
                return res.status(400).json({ error: 'State must not be empty and must not contain curly braces' });
            }
            if (containsCurlyBraces(updatedAddress.nearby_location) || !updatedAddress.nearby_location || updatedAddress.nearby_location.length < 1) {
                logger.warn('Invalid nearby location');
                return res.status(400).json({ error: 'Nearby location must not be empty and must not contain curly braces' });
            }

            userAddress.addresses[index] = updatedAddress;
            await userAddress.save();
            logger.info('Address updated successfully');
            res.status(200).json(userAddress);
        } else {
            res.status(404).json({ error: 'Address not found' });
        }
    } catch (error) {
        logger.error(`Error updating address: ${error.message}`);
        res.status(400).json({ error: error.message });
    }
};

// Delete a specific address by index for the logged-in user
exports.deleteAddress = async (req, res) => {
    try {
        const user = req.user; // Extract user from request
        const index = req.params.index;
        logger.info(`Deleting address at index ${index} for user: ${user.id}`);

        const userAddress = await Address.findOne({ where: { user_id: user.id } });

        if (userAddress && userAddress.addresses[index]) {
            userAddress.addresses.splice(index, 1);
            await userAddress.save();
            logger.info('Address deleted successfully');
            res.status(204).json();
        } else {
            res.status(404).json({ error: 'Address not found' });
        }
    } catch (error) {
        logger.error(`Error deleting address: ${error.message}`);
        res.status(500).json({ error: error.message });
    }
};