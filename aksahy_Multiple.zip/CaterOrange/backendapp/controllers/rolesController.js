// roleController.js

const Roles = require('../models/roles'); 

// const createdRoles = async (req, res) => {
//     try {
//         const rolesArray = req.body.roles; // Extract roles array from request body

//         // Create role instance with roles array
//         const createdRole = await Roles.create({ roles: rolesArray });
 
//         res.status(201).json({
//             id: createdRole.id,
//             roles: rolesArray,
//             created_at: createdRole.created_at,
//             updated_at: createdRole.updated_at,
//         }); // Respond with created roles object
//     } catch (error) {
//         res.status(500).json({ error: error.message });
//     }
// };

const createdRoles = async (req, res) => {
    try {
        const role = req.body.roles; // Extract the role string from request body

        // Create role instance with the single role string
        const createdRole = await Roles.create({ roles: role });

        logger.info(`Created role: ${createdRole.roles}`);
        res.status(201).json({ roles: createdRole }); // Respond with created role object
    } catch (error) {
        logger.error(`Error creating role: ${error.message}`);
        res.status(500).json({ error: error.message });
    }
};

const getAllRoles = async (req, res) => {
    try {
        const page = parseInt(req.query.page, 10) || 1; // Default to page 1 if not provided
        const pageSize = parseInt(req.query.pageSize, 10) || 10; // Default to 10 items per page if not provided

        const offset = (page - 1) * pageSize;
        const limit = pageSize;

        const { count, rows } = await Roles.findAndCountAll({
            offset,
            limit
        });

        logger.info(`Fetched ${rows.length} roles`);
        res.json({
            totalItems: count,
            totalPages: Math.ceil(count / pageSize),
            currentPage: page,
            roles: rows
        });
    } catch (error) {
        logger.error(`Error fetching all roles: ${error.message}`);
        res.status(500).json({ error: error.message });
    }
};

const getRoleById = async (req, res) => {
    try {
        const roleId = req.params.id; // Extract role ID from request parameters
        const role = await Roles.findByPk(roleId); // Find role by ID

        if (!role) {
            logger.warn(`Role not found for ID: ${roleId}`);
            return res.status(404).json({ message: 'Role not found' });
        }

        logger.info(`Fetched role by ID: ${roleId}`);
        res.status(200).json(role);
    } catch (error) {
        logger.error(`Error fetching role by ID: ${error.message}`);
        res.status(500).json({ error: error.message });
    }
};

const updateRole = async (req, res) => {
    try {
        const roleId = req.params.id; // Extract role ID from request parameters
        const { roles } = req.body; // Extract updated role from request body

        // Update role by ID
        await Roles.update({ roles: roles }, { where: { id: roleId } });

        logger.info(`Updated role with ID ${roleId} to ${roles}`);
        res.status(200).json({ message: `Updated role with ID ${roleId}` });

    } catch (error) {
        logger.error(`Error updating role: ${error.message}`);
        res.status(500).json({ error: error.message });
    }
};

const deleteRole = async (req, res) => {
    try {
        const roleId = req.params.id; // Extract role ID from request parameters

        // Find the role by ID
        const role = await Roles.findByPk(roleId);

        if (!role) {
            logger.warn(`Role not found for deletion: ID ${roleId}`);
            return res.status(404).json({ message: 'Role not found' });
        }

        // Delete the role
        await role.destroy();

        logger.info(`Deleted role with ID ${roleId}`);
        res.status(200).json({ message: 'Role deleted successfully' });
    } catch (error) {
        logger.error(`Error deleting role: ${error.message}`);
        res.status(500).json({ error: error.message });
    }
};

module.exports = { createdRoles, getAllRoles, getRoleById, updateRole, deleteRole };