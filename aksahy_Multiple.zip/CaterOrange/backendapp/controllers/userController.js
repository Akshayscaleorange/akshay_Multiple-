// controllers/userController.js
'use strict';

const User = require('../models/user');
const bcrypt = require('bcryptjs');
const logger = require('./logger');


// Function to log errors
const logError = (error) => {
  logger.error(error.stack || error.message);
};

// exports.getUsers = async (req, res) => {
//   try {
//     const users = await User.findAll();
//     res.json(users);
//   } catch (error) {
//     logError(error);
//     res.status(500).json({ error: error.message });
//   }
// };

exports.getUsers = async (req, res) => {
  try {
    const page = parseInt(req.query.page, 10) || 1; // Default to page 1 if not provided
    const pageSize = parseInt(req.query.pageSize, 10) || 10; // Default to 10 users per page if not provided

    const offset = (page - 1) * pageSize;
    const limit = pageSize;

    const users = await User.findAndCountAll({
      offset,
      limit
    });

    res.status(200).json({
      totalUsers: users.count,
      totalPages: Math.ceil(users.count / pageSize),
      currentPage: page,
      users: users.rows
    });
  } catch (error) {
    logError(error);
    res.status(500).json({ error: error.message });
  }
};


exports.getUser = async (req, res) => {
  try {
    const user = await User.findByPk(req.params.id);
    if (user) {
      res.json(user);
    } else {
      res.status(404).json({ error: 'User not found' });
    }
  } catch (error) {
    logError(error);
    res.status(500).json({ error: error.message });
  }
};

exports.createUser = async (req, res) => {
  try {
    const { password, confirm_password, phone_number, ...rest } = req.body;

    const existingUser = await User.findOne({ where: { email: req.body.email } });
    if (existingUser) {
      return res.status(400).json({ error: 'User with this email already exists' });
    }

    const existingPhoneNumber = await User.findOne({ where: { phone_number: phone_number.toString() } });
    if (existingPhoneNumber) {
      return res.status(400).json({ error: 'User with this phone number already exists' });
    }

    if (password !== confirm_password) {
      return res.status(400).json({ error: 'Password and confirm password do not match' });
    }

    const hashedPassword = await bcrypt.hash(password, 8);

    const newUser = await User.create({ ...rest, phone_number: phone_number.toString(), password: hashedPassword, confirm_password: hashedPassword });
    res.status(201).json(newUser);
  } catch (error) {
    logError(error);
    if (error.name === 'SequelizeValidationError') {
      res.status(400).json({ errors: error.errors.map(err => err.message) });
    } else {
      res.status(500).json({ error: error.message });
    }
  }
};

exports.updateUser = async (req, res) => {
  try {
    const { password, confirm_password, phone_number, ...rest } = req.body;

    if (password && confirm_password) {
      if (password !== confirm_password) {
        return res.status(400).json({ error: 'Password and confirm password do not match' });
      }
      const hashedPassword = await bcrypt.hash(password, 8);
      rest.password = hashedPassword;
      rest.confirm_password = hashedPassword;
    }

    if (phone_number) {
      rest.phone_number = phone_number.toString();
    }

    const [updated] = await User.update(rest, { where: { id: req.params.id } });
    if (updated) {
      const updatedUser = await User.findByPk(req.params.id);
      res.status(200).json(updatedUser);
    } else {
      res.status(404).json({ error: 'User not found' });
    }
  } catch (error) {
    logError(error);
    if (error.name === 'SequelizeValidationError') {
      res.status(400).json({ errors: error.errors.map(err => err.message) });
    } else {
      res.status(500).json({ error: error.message });
    }
  }
};

exports.deleteUser = async (req, res) => {
  try {
    const deleted = await User.destroy({ where: { id: req.params.id } });
    if (deleted) {
      logger.info(`User with ID: ${req.params.id} deleted successfully`);
      res.status(204).json();
    } else {
      res.status(404).json({ error: 'User not found' });
    }
  } catch (error) {
    logError(error);
    res.status(500).json({ error: error.message });
  }
};

// module.exports = {
//   getUsers,
//   getUser,
//   createUser,
//   updateUser,
//   deleteUser
// };