// const AWS = require('aws-sdk');
// const OrderPhotos = require('../models/photos');
// require('dotenv').config();
// const multer = require('multer');
// const storage = multer.memoryStorage();
// const upload1 = multer({
//     storage: storage,
//     limits: {
//         fileSize: 1024 * 1024 * 5  // 5MB max file size
//     },
//     fileFilter: (req, file, cb) => {
//         if (file.mimetype.startsWith('image/')) {
//             cb(null, true);
//         } else {
//             cb(new Error('Not an image! Please upload an image.'), false);
//         }
//     }
// }).single('images');  // Change to single for single file upload

// const s3 = new AWS.S3({
//     accessKeyId: process.env.AWS_ACCESS_KEY_ID,
//     secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY
// });

// // Test connection to AWS S3
// s3.listBuckets(function (err, data) {
//     if (err) {
//         console.log("Error listing buckets:", err);
//     } else {
//         console.log("Buckets:", data.Buckets);
//     }
// });

// exports.uploadPhoto = async (req, res) => {
//     try {
//         // Middleware upload1 will process the upload and add the file to req.file
//         upload1(req, res, async function (err) {
//             if (err) {
//                 console.error('Error uploading photo:', err);
//                 return res.status(500).json({ success: false, error: err.message });
//             }

//             if (!req.file) {
//                 return res.status(400).json({ success: false, error: 'No file uploaded' });
//             }

//             const file = req.file;
//             const fileName = `${Date.now()}_${file.originalname}`;
//             const s3Params = {
//                 Bucket: process.env.AWS_S3_BUCKET_NAME,
//                 Key: fileName,
//                 Body: file.buffer,
//                 ContentType: file.mimetype
//             };

//             const data = await s3.upload(s3Params).promise();
//             const photoUrl = data.Location; // This is the URL of the uploaded file in S3

//             const { orderId } = req.body;

//             await OrderPhotos.create({ order_id: orderId, photo_url: photoUrl });

//             res.status(200).json({ success: true, url: photoUrl });
//         });
//     } catch (error) {
//         console.error('Error uploading photo:', error);
//         res.status(500).json({ success: false, error: error.message });
//     }
// };

// exports.getphotos = async (req, res) => {
//     const orderId = req.params.orderId;
//     try {
//         const photos = await OrderPhotos.findAll({ where: { order_id: orderId } });
//         res.status(200).json({ success: true, photos });
//     } catch (error) {
//         console.error('Error retrieving photos:', error);
//         res.status(500).json({ success: false, error: error.message });
//     }
// };






const AWS = require('aws-sdk');
const OrderPhotos = require('../models/photos');
require('dotenv').config();
const multer = require('multer');
const storage = multer.memoryStorage();



const upload1 = multer({
    storage: storage,
    limits: {
        fileSize: 1024 * 1024 * 5  // 5MB max file size
    },
    fileFilter: (req, file, cb) => {
        if (file.mimetype.startsWith('image/')) {
            cb(null, true);
        } else {
            cb(new Error('Not an image! Please upload an image.'), false);
        }
    }
}).single('images');  // Change to single for single file upload

const s3 = new AWS.S3({
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY
});

// Test connection to AWS S3
s3.listBuckets(function (err, data) {
    if (err) {
        console.log("Error listing buckets:", err);
    } else {
        console.log("Buckets:", data.Buckets);
    }
});

exports.uploadPhoto = async (req, res) => {
    try {
        // Middleware upload1 will process the upload and add the file to req.file
        upload1(req, res, async function (err) {
            if (err) {
                console.error('Error uploading photo:', err);
                return res.status(500).json({ success: false, error: err.message });
            }

            if (!req.file) {
                return res.status(400).json({ success: false, error: 'No file uploaded' });
            }

            const { orderId } = req.body;

            if (!orderId) {
                return res.status(400).json({ success: false, error: 'orderId is required' });
            }

            const file = req.file;
            const fileName = `${Date.now()}_${file.originalname}`;
            const s3Params = {
                Bucket: process.env.AWS_S3_BUCKET_NAME,
                Key: fileName,
                Body: file.buffer,
                ContentType: file.mimetype
            };

            const data = await s3.upload(s3Params).promise();
            const photoUrl = data.Location; // This is the URL of the uploaded file in S3

            await OrderPhotos.create({ order_id: orderId, photo_url: photoUrl });

            res.status(200).json({ success: true, url: photoUrl });
        });
    } catch (error) {
        console.error('Error uploading photo:', error);
        res.status(500).json({ success: false, error: error.message });
    }
};

// exports.getPhotos = async (req, res) => {
//     const orderId = req.params.orderId;
//     try {
//         const photos = await OrderPhotos.findAll({ where: { order_id: orderId } });
//         res.status(200).json({ success: true, photos });
//     } catch (error) {
//         console.error('Error retrieving photos:', error);
//         res.status(500).json({ success: false, error: error.message });
//     }
// };


exports.getPhotos = async (req, res) => {
    const orderId = req.params.orderId;
    try {
        const page = parseInt(req.query.page, 10) || 1; // Default to page 1 if not provided
        const pageSize = parseInt(req.query.pageSize, 10) || 10; // Default to 10 items per page if not provided

        const offset = (page - 1) * pageSize;
        const limit = pageSize;

        const photos = await OrderPhotos.findAndCountAll({
            where: { order_id: orderId },
            offset,
            limit
        });

        res.status(200).json({
            success: true,
            totalItems: photos.count,
            totalPages: Math.ceil(photos.count / pageSize),
            currentPage: page,
            photos: photos.rows
        });
    } catch (error) {
        console.error('Error retrieving photos:', error);
        res.status(500).json({ success: false, error: error.message });
    }
};