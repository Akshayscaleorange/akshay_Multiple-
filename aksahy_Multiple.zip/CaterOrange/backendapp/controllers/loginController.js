'use strict';

const Admin = require('../models/admin');
const User = require('../models/user');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const logger = require('./logger');



// Function to check for potentially malicious input
const containsMaliciousInput = (input) => {
    if (typeof input === 'string') {
        return /\{.*\}/.test(input) || /[<>'"%;]/.test(input); // Add other characters as needed
    }
    return false;
};

exports.Adminlogin = async (req, res) => {
    try {
        const { username, password } = req.body;

        // Check for potentially malicious input
        if (containsMaliciousInput(username) || containsMaliciousInput(password)) {
            logger.warn('Invalid input for Admin login');
            return res.status(400).json({ error: 'Invalid input' });
        }

        // Search for the admin by username
        const admin = await Admin.findOne({ where: { username } });

        if (!admin) {
            logger.warn(`Admin not found with username: ${username}`);
            return res.status(404).json({ error: 'Admin not found' });
        }

        // Compare the hashed password
        const isMatch = await bcrypt.compare(password, admin.password);

        if (!isMatch) {
            logger.warn(`Invalid password for admin: ${username}`);
            return res.status(400).json({ error: 'Invalid password' });
        }

        const token = admin.generateAuthToken();
        admin.accesstoken = token;
        await admin.save();

        logger.info(`Admin logged in successfully: ${username}`);
        res.status(200).json({ token });
    } catch (error) {
        logger.error(`Error during Admin login: ${error.message}`);
        res.status(500).json({ error: error.message });
    }
};

exports.userlogin = async (req, res) => {
    try {
        const { email, password } = req.body;

        // Check for potentially malicious input
        if (containsMaliciousInput(email) || containsMaliciousInput(password)) {
            logger.warn('Invalid input for User login');
            return res.status(400).json({ error: 'Invalid input' });
        }

        // Find the user by email
        const user = await User.findOne({ where: { email } });

        if (!user) {
            logger.warn(`User not found with email: ${email}`);
            return res.status(404).json({ error: 'User not found' });
        }

        // Compare the hashed password
        const isMatch = await bcrypt.compare(password, user.password);

        if (!isMatch) {
            logger.warn(`Invalid password for user: ${email}`);
            return res.status(400).json({ error: 'Invalid password' });
        }

        // Generate the JWT token
        const token = user.generateAuthToken();
        user.accesstoken = token;
        await user.save();

        logger.info(`User logged in successfully: ${email}`);
        res.status(200).json({ token });
    } catch (error) {
        logger.error(`Error during User login: ${error.message}`);
        res.status(500).json({ error: error.message });
    }
};