// const Order = require('../models/orders');
// const User = require('../models/user');
// const Address = require('../models/address');

// exports.createOrder = async (req, res) => {
//     try {
//         const { userId, addressId, item_details, payment_id, payment_status, media } = req.body;

//         // Fetch user and address details
//         const user = await User.findByPk(userId);
//         const address = await Address.findByPk(addressId);

//         if (!user || !address) {
//             return res.status(404).json({ message: 'User or Address not found' });
//         }

//         // Create an order with user and address details
//         const order = await Order.create({
//             user_id: user.id,
//             firstname: user.firstname,
//             lastname: user.lastname,
//             email: user.email,
//             address_id: address.id,
//             contact_number: address.contact_number,
//             full_address: address.full_address,
//             pincode: address.pincode,
//             latitude: address.latitude,
//             longitude: address.longitude,
//             state: address.state,
//             nearby_location: address.nearby_location,
//             item_details,
//             payment_id,
//             payment_status,
//             media,
//         });

//         res.status(201).json(order);
//     } catch (error) {
//         console.error('Error creating order:', error);
//         res.status(500).json({ message: 'Internal server error' });
//     }
// };

// exports.getOrders = async (req, res) => {
//     try {
//         const orders = await Order.findAll();
//         res.status(200).json(orders);
//     } catch (error) {
//         console.error('Error fetching orders:', error);
//         res.status(500).json({ message: 'Internal server error' });
//     }
// };













const Order = require('../models/orders');
const OrderItem = require('../models/orderItem');
const User = require('../models/user');
const Product = require('../models/products');
const logger = require('./logger');


// Function to check for potentially malicious input
const containsMaliciousInput = (input) => {
    if (typeof input === 'string') {
        return /\{.*\}/.test(input) || /[<>'"%;]/.test(input); // Add other characters as needed
    }
    return false;
};

exports.createOrder = async (req, res) => {
    try {
        const { address_details, item_details, payment_id, payment_status, TotalPrice, merchantTransactionId } = req.body;
        const user = req.user; // Extract user from request

        // Validate input
        if (containsMaliciousInput(address_details) || containsMaliciousInput(payment_id) || containsMaliciousInput(payment_status) || containsMaliciousInput(merchantTransactionId)) {
            logger.warn('Invalid input detected in createOrder function');
            return res.status(400).json({ error: 'Invalid input' });
        }

        // Create an order
        const order = await Order.create({
            user_id: user.id,
            address_details,
            payment_id,
            payment_status,
            TotalPrice,
            merchantTransactionId
        });

        // Create order items
        for (const item of item_details) {
            if (containsMaliciousInput(item.ProductName) || containsMaliciousInput(item.DateOfDelivery)) {
                logger.warn('Invalid input detected in order items');
                return res.status(400).json({ error: 'Invalid input in order items' });
            }

            await OrderItem.create({
                order_id: order.id,
                product_id: item.ProductId,
                ProductName: item.ProductName,
                ProductQuantity: item.ProductQuantity,
                ProductPrice: item.ProductPrice,
                ProductTotalPrice: item.ProductTotalPrice,
                dates_of_delivery: item.DateOfDelivery, // Ensure dates_of_delivery is passed correctly
            });
        }

        logger.info(`Order created successfully: Order ID ${order.id}`);
        res.status(201).json(order);
    } catch (error) {
        logger.error(`Error creating order: ${error.message}`);
        res.status(500).json({ message: 'Internal server error' });
    }
};

// exports.getOrders = async (req, res) => {
//     try {
//         const user = req.user; // Extract user from request
//         const orders = await Order.findAll({
//             where: { user_id: user.id },
//             include: [
//                 { model: User },
//                 {
//                     model: OrderItem,
//                     include: [Product]
//                 }
//             ]
//         });
//         res.status(200).json(orders);
//     } catch (error) {
//         console.error('Error fetching orders:', error);
//         res.status(500).json({ message: 'Internal server error' });
//     }
// };

// exports.getOrders = async (req, res) => {
//     try {
//         const user = req.user; // Extract user from request
//         const admin = req.admin; // Extract admin from request

//         let orders;
//         if (admin) {
//             // Admin can fetch all orders
//             orders = await Order.findAll({
//                 include: [
//                     { model: User },
//                     {
//                         model: OrderItem,
//                         include: [Product]
//                     }
//                 ]
//             });
//         } else if (user) {
//             // Regular user can fetch only their own orders
//             orders = await Order.findAll({
//                 where: { user_id: user.id },
//                 include: [
//                     { model: User },
//                     {
//                         model: OrderItem,
//                         include: [Product]
//                     }
//                 ]
//             });
//         } else {
//             logger.warn('Unauthorized access to getOrders');
//             return res.status(401).json({ error: 'Unauthorized' });
//         }

//         logger.info(`Orders fetched successfully: ${orders.length} orders`);
//         res.status(200).json(orders);
//     } catch (error) {
//         logger.error(`Error fetching orders: ${error.message}`);
//         res.status(500).json({ message: 'Internal server error' });
//     }
// };

exports.getOrderById = async (req, res) => {
    try {
        const { orderId } = req.params;
        const user = req.user; // Extract user from request

        if (containsMaliciousInput(orderId)) {
            logger.warn('Invalid order ID detected in getOrderById');
            return res.status(400).json({ error: 'Invalid order ID' });
        }

        const order = await Order.findByPk(orderId, {
            include: [
                { model: User },
                {
                    model: OrderItem,
                    include: [Product]
                }
            ]
        });

        if (!order || order.user_id !== user.id) {
            logger.warn(`Order not found or does not belong to the user: Order ID ${orderId}`);
            return res.status(404).json({ message: 'Order not found or does not belong to the user' });
        }

        logger.info(`Order fetched successfully: Order ID ${orderId}`);
        res.status(200).json(order);
    } catch (error) {
        logger.error(`Error fetching order: ${error.message}`);
        res.status(500).json({ message: 'Internal server error' });
    }
};



exports.getOrders = async (req, res) => {
    try {
        const user = req.user; // Extract user from request
        const admin = req.admin; // Extract admin from request

        const page = parseInt(req.query.page, 10) || 1; // Default to page 1 if not provided
        const pageSize = parseInt(req.query.pageSize, 10) || 10; // Default to 10 items per page if not provided

        const offset = (page - 1) * pageSize;
        const limit = pageSize;

        let orders;
        if (admin) {
            // Admin can fetch all orders
            const { count, rows } = await Order.findAndCountAll({
                include: [
                    { model: User },
                    {
                        model: OrderItem,
                        include: [Product]
                    }
                ],
                offset,
                limit
            });
            orders = { count, rows };
        } else if (user) {
            // Regular user can fetch only their own orders
            const { count, rows } = await Order.findAndCountAll({
                where: { user_id: user.id },
                include: [
                    { model: User },
                    {
                        model: OrderItem,
                        include: [Product]
                    }
                ],
                offset,
                limit
            });
            orders = { count, rows };
        } else {
            logger.warn('Unauthorized access to getOrders');
            return res.status(401).json({ error: 'Unauthorized' });
        }

        logger.info(`Orders fetched successfully: ${orders.rows.length} orders`);
        res.status(200).json({
            totalItems: orders.count,
            totalPages: Math.ceil(orders.count / pageSize),
            currentPage: page,
            orders: orders.rows
        });
    } catch (error) {
        logger.error(`Error fetching orders: ${error.message}`);
        res.status(500).json({ message: 'Internal server error' });
    }
};

// exports.getOrderById = async (req, res) => {
//     try {
//         const { orderId } = req.params;
//         const user = req.user; // Extract user from request
//         const admin = req.admin; // Extract admin from request

//         if (containsMaliciousInput(orderId)) {
//             logger.warn('Invalid order ID detected in getOrderById');
//             return res.status(400).json({ error: 'Invalid order ID' });
//         }

//         const page = parseInt(req.query.page, 10) || 1; // Default to page 1 if not provided
//         const pageSize = parseInt(req.query.pageSize, 10) || 10; // Default to 10 items per page if not provided

//         const offset = (page - 1) * pageSize;
//         const limit = pageSize;

//         let order;
//         if (admin) {
//             order = await Order.findByPk(orderId, {
//                 include: [
//                     { model: User },
//                     {
//                         model: OrderItem,
//                         include: [Product]
//                     }
//                 ],
//                 offset,
//                 limit
//             });
//         } else if (user) {
//             order = await Order.findByPk(orderId, {
//                 where: { user_id: user.id },
//                 include: [
//                     { model: User },
//                     {
//                         model: OrderItem,
//                         include: [Product]
//                     }
//                 ],
//                 offset,
//                 limit
//             });
//         } else {
//             logger.warn('Unauthorized access to getOrderById');
//             return res.status(401).json({ error: 'Unauthorized' });
//         }

//         if (!order) {
//             logger.warn(`Order not found or does not belong to the user: Order ID ${orderId}`);
//             return res.status(404).json({ message: 'Order not found or does not belong to the user' });
//         }

//         logger.info(`Order fetched successfully: Order ID ${orderId}`);
//         res.status(200).json(order);
//     } catch (error) {
//         logger.error(`Error fetching order: ${error.message}`);
//         res.status(500).json({ message: 'Internal server error' });
//     }
// };


exports.updateOrder = async (req, res) => {
    try {
        const { orderId } = req.params;
        const { address_details, item_details, payment_id, payment_status, TotalPrice } = req.body;
        const user = req.user; // Extract user from request

        if (containsMaliciousInput(orderId) || containsMaliciousInput(address_details) || containsMaliciousInput(payment_id) || containsMaliciousInput(payment_status)) {
            logger.warn('Invalid input detected in updateOrder');
            return res.status(400).json({ error: 'Invalid input' });
        }

        const order = await Order.findByPk(orderId);

        if (!order || order.user_id !== user.id) {
            logger.warn(`Order not found or does not belong to the user: Order ID ${orderId}`);
            return res.status(404).json({ message: 'Order not found or does not belong to the user' });
        }

        // Update order details
        order.address_details = address_details || order.address_details;
        order.payment_id = payment_id || order.payment_id;
        order.payment_status = payment_status || order.payment_status;
        order.TotalPrice = TotalPrice || order.TotalPrice;
        await order.save();

        // Delete existing order items and create new ones
        await OrderItem.destroy({ where: { order_id: order.id } });

        for (const item of item_details) {
            if (containsMaliciousInput(item.ProductName) || containsMaliciousInput(item.DateOfDelivery)) {
                logger.warn('Invalid input detected in order items');
                return res.status(400).json({ error: 'Invalid input in order items' });
            }

            await OrderItem.create({
                order_id: order.id,
                product_id: item.ProductId,
                ProductName: item.ProductName,
                ProductQuantity: item.ProductQuantity,
                ProductPrice: item.ProductPrice,
                ProductTotalPrice: item.ProductTotalPrice,
                dates_of_delivery: item.DateOfDelivery,
            });
        }

        const updatedOrder = await Order.findByPk(orderId, {
            include: [
                { model: User },
                {
                    model: OrderItem,
                    include: [Product]
                }
            ]
        });

        logger.info(`Order updated successfully: Order ID ${orderId}`);
        res.status(200).json(updatedOrder);
    } catch (error) {
        logger.error(`Error updating order: ${error.message}`);
        res.status(500).json({ message: 'Internal server error' });
    }
};

exports.deleteOrder = async (req, res) => {
    try {
        const { orderId } = req.params;
        const user = req.user; // Extract user from request

        if (containsMaliciousInput(orderId)) {
            logger.warn('Invalid order ID detected in deleteOrder');
            return res.status(400).json({ error: 'Invalid order ID' });
        }

        const order = await Order.findByPk(orderId);

        if (!order || order.user_id !== user.id) {
            logger.warn(`Order not found or does not belong to the user: Order ID ${orderId}`);
            return res.status(404).json({ message: 'Order not found or does not belong to the user' });
        }

        await Order.destroy({ where: { id: orderId } });

        logger.info(`Order deleted successfully: Order ID ${orderId}`);
        res.status(204).json();
    } catch (error) {
        logger.error(`Error deleting order: ${error.message}`);
        res.status(500).json({ message: 'Internal server error' });
    }
};