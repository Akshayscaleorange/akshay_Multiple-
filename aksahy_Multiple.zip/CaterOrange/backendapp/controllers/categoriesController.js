'use strict';

const Category = require('../models/categories');
const Subcategory = require('../models/subcategories');
const logger = require('./logger');

// Function to check for potentially malicious input
const containsMaliciousInput = (input) => {
    if (typeof input === 'string') {
        return /\{.*\}/.test(input) || /[<>'"%;]/.test(input); // Add other characters as needed
    }
    return false;
};

exports.getCategories = async (req, res) => {
    try {
        const categories = await Category.findAll();
        logger.info('Fetched all categories');
        res.json(categories);
    } catch (error) {
        logger.error(`Error fetching categories: ${error.message}`);
        res.status(500).json({ error: error.message });
    }
};

exports.getCategory = async (req, res) => {
    try {
        const id = req.params.id;

        // Check for potentially malicious input
        if (containsMaliciousInput(id)) {
            logger.warn('Invalid category ID');
            return res.status(400).json({ error: 'Invalid ID' });
        }

        const category = await Category.findByPk(id);
        if (category) {
            logger.info(`Fetched category with ID: ${id}`);
            res.json(category);
        } else {
            logger.warn(`Category not found with ID: ${id}`);
            res.status(404).json({ error: 'Category not found' });
        }
    } catch (error) {
        logger.error(`Error fetching category: ${error.message}`);
        res.status(500).json({ error: error.message });
    }
};


exports.getCategories = async (req, res) => {
    try {
        const page = parseInt(req.query.page, 10) || 1; // Default to page 1 if not provided
        const pageSize = parseInt(req.query.pageSize, 10) || 10; // Default to 10 items per page if not provided

        const offset = (page - 1) * pageSize;
        const limit = pageSize;

        const { count, rows } = await Category.findAndCountAll({ offset, limit });

        logger.info('Fetched all categories');
        res.json({
            totalItems: count,
            totalPages: Math.ceil(count / pageSize),
            currentPage: page,
            categories: rows
        });
    } catch (error) {
        logger.error(`Error fetching categories: ${error.message}`);
        res.status(500).json({ error: error.message });
    }
};

// exports.getCategory = async (req, res) => {
//     try {
//         const id = req.params.id;

//         // Check for potentially malicious input
//         if (containsMaliciousInput(id)) {
//             logger.warn('Invalid category ID');
//             return res.status(400).json({ error: 'Invalid ID' });
//         }

//         const page = parseInt(req.query.page, 10) || 1; // Default to page 1 if not provided
//         const pageSize = parseInt(req.query.pageSize, 10) || 10; // Default to 10 items per page if not provided

//         const offset = (page - 1) * pageSize;
//         const limit = pageSize;

//         const { count, rows } = await Category.findAndCountAll({
//             where: { id },
//             offset,
//             limit
//         });

//         if (rows.length > 0) {
//             logger.info(`Fetched category with ID: ${id}`);
//             res.json({
//                 totalItems: count,
//                 totalPages: Math.ceil(count / pageSize),
//                 currentPage: page,
//                 categories: rows
//             });
//         } else {
//             logger.warn(`Category not found with ID: ${id}`);
//             res.status(404).json({ error: 'Category not found' });
//         }
//     } catch (error) {
//         logger.error(`Error fetching category: ${error.message}`);
//         res.status(500).json({ error: error.message });
//     }
// };


exports.createCategory = async (req, res) => {
    try {
        const { name, description } = req.body;

        // Check for potentially malicious input
        if (containsMaliciousInput(name) || containsMaliciousInput(description)) {
            logger.warn('Invalid input for creating category');
            return res.status(400).json({ error: 'Invalid input' });
        }

        const newCategory = await Category.create(req.body);
        logger.info(`Category created with ID: ${newCategory.id}`);
        res.status(201).json(newCategory);
    } catch (error) {
        logger.error(`Error creating category: ${error.message}`);
        res.status(500).json({ error: error.message });
    }
};

exports.updateCategory = async (req, res) => {
    try {
        const id = req.params.id;
        const { name, description } = req.body;

        // Check for potentially malicious input
        if (containsMaliciousInput(id) || containsMaliciousInput(name) || containsMaliciousInput(description)) {
            logger.warn('Invalid input for updating category');
            return res.status(400).json({ error: 'Invalid input' });
        }

        const [updated] = await Category.update(req.body, { where: { id } });
        if (updated) {
            const updatedCategory = await Category.findByPk(id);
            logger.info(`Category updated with ID: ${id}`);
            res.status(200).json(updatedCategory);
        } else {
            logger.warn(`Category not found for updating with ID: ${id}`);
            res.status(404).json({ error: 'Category not found' });
        }
    } catch (error) {
        logger.error(`Error updating category: ${error.message}`);
        res.status(500).json({ error: error.message });
    }
};

exports.deleteCategory = async (req, res) => {
    try {
        const id = req.params.id;

        // Check for potentially malicious input
        if (containsMaliciousInput(id)) {
            logger.warn('Invalid category ID for deletion');
            return res.status(400).json({ error: 'Invalid ID' });
        }

        const subcategories = await Subcategory.findAll({ where: { category_id: id } });
        if (subcategories.length > 0) {
            logger.warn(`Cannot delete category with ID ${id} because it has dependent subcategories`);
            return res.status(400).json({ error: 'Category has dependent subcategories. Please delete them first.' });
        }

        const deleted = await Category.destroy({ where: { id } });
        if (deleted) {
            logger.info(`Category deleted with ID: ${id}`);
            res.status(204).json();
        } else {
            logger.warn(`Category not found for deletion with ID: ${id}`);
            res.status(404).json({ error: 'Category not found' });
        }
    } catch (error) {
        logger.error(`Error deleting category: ${error.message}`);
        res.status(500).json({ error: error.message });
    }
};
