import React from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
} from "react-router-dom";
import Signin from './admin/components/Signin'
import Products from "./admin/components/header";
import PrivateRoute from "./Redux/PrivateRoute";


function App() {
  return (
    <React.Fragment >
      <Router>
        <Routes>
          <Route path="/" element={<Signin />} />
          <Route element={<PrivateRoute />}>
            <Route path="/index/*" element={<Products />} />
          </Route>
        </Routes>
      </Router>
    </React.Fragment>
  );
}



export default App;
