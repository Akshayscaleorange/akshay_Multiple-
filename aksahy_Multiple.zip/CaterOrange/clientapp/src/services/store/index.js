import React from 'react'

export default function store() {
  return (
    <div>store</div>
  )
}
