
import React from 'react'
import Header from '../admin/components/header'
import Footer from '../admin/components/footer'

const Layout = ({ children }) => {

    return (
        <div>
            <div> <Header /></div>
            {children}
            <div> <Footer /></div>
        </div>
    )
}

export default Layout
