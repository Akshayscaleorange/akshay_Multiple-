import React, { useEffect, useState } from 'react';
import axios from 'axios';
import {
    Dialog, DialogTitle, DialogContent, DialogActions,
    TextField, Button, Snackbar, Alert, Grid,
    FormControl, InputLabel, Select, MenuItem
} from '@mui/material';

const SubcategoryFormModal = ({ open, handleClose, fetchSubcategories, subcategory, onSuccess }) => {
    const [subcategoryName, setSubcategoryName] = useState('');
    const [selectedCategoryId, setSelectedCategoryId] = useState('');
    const [categories, setCategories] = useState([]);
    const [alert, setAlert] = useState({ open: false, message: '', severity: 'success' });

    useEffect(() => {
        if (subcategory) {
            setSubcategoryName(subcategory.subcategory_name);
            setSelectedCategoryId(subcategory.category_id || '');
        } else {
            setSubcategoryName('');
            setSelectedCategoryId('');
        }
        fetchCategories();
    }, [subcategory]);

    const handleChange = (e) => {
        setSubcategoryName(e.target.value);
    };

    const handleCategoryChange = (e) => {
        setSelectedCategoryId(e.target.value);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const token = localStorage.getItem('token');
        try {
            if (subcategory) {
                await axios.put(`http://localhost:9000/api/subcategories/${subcategory.id}`, {
                    subcategory_name: subcategoryName,
                    category_id: selectedCategoryId
                }, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });
                setAlert({ open: true, message: 'Subcategory updated successfully!', severity: 'success' });
            } else {
                await axios.post('http://localhost:9000/api/subcategories', {
                    subcategory_name: subcategoryName,
                    category_id: selectedCategoryId
                }, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });
                setAlert({ open: true, message: 'Subcategory added successfully!', severity: 'success' });
            }
            fetchSubcategories();
            handleClose();
            onSuccess('Subcategory added/updated successfully!', 'success');
        } catch (error) {
            console.error('Error creating/updating subcategory:', error);
            setAlert({ open: true, message: 'Error creating/updating subcategory!', severity: 'error' });
            onSuccess('Error creating/updating subcategory!', 'error');
        }
    };

    const handleCloseAlert = () => {
        setAlert({ ...alert, open: false });
    };

    const fetchCategories = async () => {
        const token = localStorage.getItem('token');
        try {
            const response = await axios.get('http://localhost:9000/api/categories', {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            });
            setCategories(response.data.categories);
        } catch (error) {
            console.error('Error fetching categories:', error);
        }
    };

    return (
        <Dialog
            open={open}
            onClose={() => {
                handleClose();
                setAlert({ open: false, message: '', severity: 'success' });
            }}
            maxWidth="xl"
            fullWidth
            PaperProps={{
                style: {
                    minHeight: '80vh',
                    maxHeight: '90vh'
                }
            }}
        >
            <DialogTitle style={{ marginTop: '35px', color: 'blue', fontWeight: 'bold' }}>
                {subcategory ? 'Update Subcategory' : 'Add Subcategory'}
            </DialogTitle>
            <DialogContent dividers style={{ paddingTop: '50px', textAlign: 'center', paddingLeft: '60px', paddingRight: '60px' }}>
                <form onSubmit={handleSubmit}>
                    <Grid container spacing={5} justifyContent="center" textAlign="center">
                        <Grid item xs={12}>
                            <TextField
                                margin="dense"
                                required
                                fullWidth
                                label="Subcategory"
                                name="subcategory_name"
                                value={subcategoryName}
                                onChange={handleChange}
                                variant="outlined"
                            />
                        </Grid>
                        <Grid item xs={12}>
                            <FormControl fullWidth margin="dense">
                                <InputLabel id="category-select-label">Category</InputLabel>
                                <Select
                                    labelId="category-select-label"
                                    id="category-select"
                                    value={selectedCategoryId}
                                    onChange={handleCategoryChange}
                                    variant="outlined"
                                    label="Category"
                                >
                                    {categories.map((category) => (
                                        <MenuItem key={category.id} value={category.id}>
                                            {category.category_name}
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        </Grid>
                    </Grid>
                    <Snackbar
                        open={alert.open}
                        autoHideDuration={6000}
                        onClose={handleCloseAlert}
                        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
                    >
                        <Alert onClose={handleCloseAlert} severity={alert.severity} sx={{ width: '100%' }}>
                            {alert.message}
                        </Alert>
                    </Snackbar>
                    <DialogActions style={{ justifyContent: 'flex-end', padding: '20px 60px', marginTop: '200px' }}>
                        <Button
                            onClick={handleClose}
                            color="primary"
                            size="large"
                        >
                            Cancel
                        </Button>
                        <Button
                            type="submit"
                            color="primary"
                            size="large"
                        >
                            {subcategory ? 'Update Subcategory' : 'Add Subcategory'}
                        </Button>
                    </DialogActions>
                </form>
            </DialogContent>
        </Dialog>
    );
};

export default SubcategoryFormModal;



////


// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import {
//   Typography, TextField, Button, IconButton, Snackbar, Alert, Grid, DialogActions, Dialog, DialogTitle, DialogContent
// } from '@mui/material';

// const SubcategoryFormModal = ({ open, handleClose, fetchSubcategories, subcategory, onSuccess }) => {
//   const [subcategoryType, setSubcategoryType] = useState('');
//   const [alert, setAlert] = useState({ open: false, message: '', severity: 'success' });

//   useEffect(() => {
//     if (subcategory) {
//       setSubcategoryType(subcategory.subcategory_type);
//     } else {
//       setSubcategoryType('');
//     }
//   }, [subcategory]);

//   const handleChange = (e) => {
//     setSubcategoryType(e.target.value);
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     const token = localStorage.getItem('token');
//     try {
//       if (subcategory) {
//         // Update existing subcategory
//         await axios.put(`http://localhost:9000/api/subcategories/${subcategory.id}`, { subcategory_type: subcategoryType }, {
//           headers: {
//             Authorization: `Bearer ${token}`,
//           },
//         });
//         setAlert({ open: true, message: 'Subcategory updated successfully!', severity: 'success' });
//       } else {
//         // Add new subcategory
//         await axios.post('http://localhost:9000/api/subcategories', { subcategory_type: subcategoryType }, {
//           headers: {
//             Authorization: `Bearer ${token}`,
//           },
//         });
//         setAlert({ open: true, message: 'Subcategory added successfully!', severity: 'success' });
//       }
//       fetchSubcategories();
//       handleClose();
//       onSuccess('Subcategory added/updated successfully!', 'success');
//     } catch (error) {
//       console.error('Error creating/updating subcategory:', error);
//       setAlert({ open: true, message: 'Error creating/updating subcategory!', severity: 'error' });
//       onSuccess('Error creating/updating subcategory!', 'error');
//     }
//   };

//   const handleCloseAlert = () => {
//     setAlert({ ...alert, open: false });
//   };

//   return (
//     <Dialog
//       open={open}
//       onClose={() => {
//         handleClose();
//         setAlert({ open: false, message: '', severity: 'success' });
//       }}
//       maxWidth="xl"
//       fullWidth
//       PaperProps={{
//         style: {
//           minHeight: '80vh',
//           maxHeight: '90vh'
//         }
//       }}
//     >
//       <DialogTitle style={{ marginTop: '35px', color: 'blue', fontWeight: 'bold' }}>
//         {subcategory ? 'Update Subcategory' : 'Add Subcategory'}
//       </DialogTitle>
//       <DialogContent dividers style={{ paddingTop: '50px', textAlign: 'center', paddingLeft: '60px', paddingRight: '60px' }}>
//         <form onSubmit={handleSubmit}>
//           <Grid container spacing={5} justifyContent="center" textAlign="center">
//             <Grid item xs={12}>
//               <TextField
//                 margin="dense"
//                 required
//                 fullWidth
//                 label="Subcategory"
//                 name="subcategory_type"
//                 value={subcategoryType}
//                 onChange={handleChange}
//                 variant="outlined"
//               />
//             </Grid>
//           </Grid>
//           <Snackbar
//             open={alert.open}
//             autoHideDuration={6000}
//             onClose={handleCloseAlert}
//             anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
//           >
//             <Alert onClose={handleCloseAlert} severity={alert.severity} sx={{ width: '100%' }}>
//               {alert.message}
//             </Alert>
//           </Snackbar>
//           <DialogActions style={{ justifyContent: 'flex-end', padding: '20px 60px', marginTop: '300px' }}>
//             <Button
//               onClick={handleClose}
//               color="primary"
//               size="large"
//             >
//               Cancel
//             </Button>
//             <Button
//               type="submit"
//               color="primary"
//               size="large"
//             >
//               {subcategory ? 'Update Subcategory' : 'Add Subcategory'}
//             </Button>
//           </DialogActions>
//         </form>
//       </DialogContent>
//     </Dialog>
//   );
// };

// export default SubcategoryFormModal;



// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import { Typography, TextField, Button, IconButton, Snackbar, Alert, Grid, DialogActions, Dialog, DialogTitle, DialogContent } from '@mui/material';

// // const style = {
// //   position: 'absolute',
// //   top: '50%',
// //   left: '50%',
// //   transform: 'translate(-50%, -50%)',
// //   width: 400,
// //   bgcolor: 'background.paper',
// //   border: '2px solid #000',
// //   boxShadow: 24,
// //   p: 4,
// // };

// const SubcategoryFormModal = ({ open, handleClose, fetchSubcategories, subcategory }) => {
//   const [subcategoryType, setSubcategoryType] = useState('');
//   const [alert, setAlert] = useState({ open: false, message: '', severity: 'success' });

//   useEffect(() => {
//     if (subcategory) {
//       setSubcategoryType(subcategory.subcategory_type);
//     } else {
//       setSubcategoryType('');
//     }
//   }, [subcategory]);

//   const handleChange = (e) => {
//     setSubcategoryType(e.target.value);
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     const token = localStorage.getItem('token');
//     try {
//       if (subcategory) {
//         // Update existing subcategory
//         await axios.put(`http://localhost:9000/api/subcategories/${subcategory.id}`, { subcategory_type: subcategoryType }, {
//           headers: {
//             Authorization: `Bearer ${token}`,
//           },
//         });
//         setAlert({ open: true, message: 'Subcategory updated successfully!', severity: 'success' });
//       } else {
//         // Add new subcategory
//         await axios.post('http://localhost:9000/api/subcategories', { subcategory_type: subcategoryType }, {
//           headers: {
//             Authorization: `Bearer ${token}`,
//           },
//         });
//         setAlert({ open: true, message: 'Subcategory added successfully!', severity: 'success' });
//       }
//       fetchSubcategories();
//     } catch (error) {
//       console.error('Error creating/updating subcategory:', error);
//       setAlert({ open: true, message: 'Error creating/updating subcategory!', severity: 'error' });
//     }
//   };

//   const handleCloseAlert = () => {
//     setAlert({ ...alert, open: false });
//   };

//   const style = {
//     minHeight: '300px',
//     padding: '100px',
//     border: '1px solid #ccc',
//     borderRadius: '8px',
//     alignItems: 'center'
//   };


//   return (
//     <Dialog
//       open={open}
//       onClose={() => {
//         handleClose();
//         setAlert({ open: false, message: '', severity: 'success' }); // Reset alert state on close
//       }}
//       maxWidth="xl"
//       fullWidth
//       PaperProps={{
//         style: {
//           minHeight: '80vh',
//           maxHeight: '90vh'  
//         }
//       }}
//     >
//       <DialogTitle style={{ marginTop: '35px', color: 'blue', fontWeight: 'bold' }}>
//         {subcategory ? 'Update Subcategory' : 'Add Subcategory'}
//       </DialogTitle>
//       <DialogContent dividers style={{ paddingTop: '50px', textAlign: 'center', paddingLeft: '60px', paddingRight: '60px' }}>
//         <form onSubmit={handleSubmit}>
//           <Grid container spacing={5} justifyContent="center" textAlign="center">
//             <Grid item xs={12}>
//               <TextField
//                 margin="dense"
//                 required
//                 fullWidth
//                 label="Subcategory"
//                 name="subcategory_type"
//                 value={subcategoryType}
//                 onChange={handleChange}
//                 variant="outlined"
//               />
//             </Grid>
//           </Grid>
//           <Snackbar
//             open={alert.open}
//             autoHideDuration={6000}
//             onClose={handleCloseAlert}
//             anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
//           >
//             <Alert onClose={handleCloseAlert} severity={alert.severity} sx={{ width: '100%' }}>
//               {alert.message}
//             </Alert>
//           </Snackbar>
//           <DialogActions style={{ justifyContent: 'flex-end', padding: '20px 60px' , marginTop: '300px' }}>
//             <Button
//               onClick={handleClose}
//               color="primary"
//               size="large"
//             >
//               Cancel
//             </Button>
//             <Button
//               type="submit"
//               color="primary"
//               size="large"
//             >
//               {subcategory ? 'Update Subcategory' : 'Add Subcategory'}
//             </Button>
//           </DialogActions>
//         </form>
//       </DialogContent>
//     </Dialog>
//   );
// };

// export default SubcategoryFormModal;