import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { format } from 'date-fns';
import { Box, Grid, Button, Snackbar, IconButton, Dialog, DialogActions, DialogContent, DialogTitle, Typography } from '@mui/material';
import { DataGrid } from '@mui/x-data-grid';
import Alert from '@mui/material/Alert';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import SubcategoryFormModal from './SubcategoryFormModal';
import CategoryFormModal from './CategoryFormModal';

const AddCategoryAndSubcategory = () => {
    const [subcategories, setSubcategories] = useState([]);
    const [categories, setCategories] = useState([]);
    const [alert, setAlert] = useState({ open: false, message: '', severity: 'success' });

    const [isSubcategoryModalOpen, setIsSubcategoryModalOpen] = useState(false);
    const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
    const [selectedSubcategory, setSelectedSubcategory] = useState(null);
    const [selectedCategory, setSelectedCategory] = useState(null);

    const [confirmOpen, setConfirmOpen] = useState(false);
    const [deleteItem, setDeleteItem] = useState({ id: null, type: '' });

    useEffect(() => {
        fetchSubcategories();
        fetchCategories();
    }, []);

    const fetchSubcategories = async () => {
        const token = localStorage.getItem('token');
        try {
            const response = await axios.get('http://localhost:9000/api/subcategories', {
                headers: { Authorization: `Bearer ${token}` },
            });
            setSubcategories(response.data.subcategories);
        } catch (error) {
            console.error('Error fetching subcategories:', error);
            setAlert({ open: true, message: 'Error fetching subcategories!', severity: 'error' });
        }
    };

    const fetchCategories = async () => {
        const token = localStorage.getItem('token');
        try {
            const response = await axios.get('http://localhost:9000/api/categories', {
                headers: { Authorization: `Bearer ${token}` },
            });
            setCategories(response.data.categories);
        } catch (error) {
            console.error('Error fetching categories:', error);
            setAlert({ open: true, message: 'Error fetching categories!', severity: 'error' });
        }
    };

    const handleOpenSubcategoryModal = (subcategory = null) => {
        setSelectedSubcategory(subcategory);
        setIsSubcategoryModalOpen(true);
    };

    const handleCloseSubcategoryModal = () => {
        setIsSubcategoryModalOpen(false);
        setSelectedSubcategory(null);
    };

    const handleOpenCategoryModal = (category = null) => {
        setSelectedCategory(category);
        setIsCategoryModalOpen(true);
    };

    const handleCloseCategoryModal = () => {
        setIsCategoryModalOpen(false);
        setSelectedCategory(null);
    };

    const handleDeleteItem = async () => {
        const token = localStorage.getItem('token');
        try {
            if (deleteItem.type === 'subcategory') {
                await axios.delete(`http://localhost:9000/api/subcategories/${deleteItem.id}`, {
                    headers: { Authorization: `Bearer ${token}` },
                });
                setAlert({ open: true, message: 'Subcategory deleted successfully!', severity: 'success' });
                fetchSubcategories();
            } else if (deleteItem.type === 'category') {
                await axios.delete(`http://localhost:9000/api/categories/${deleteItem.id}`, {
                    headers: { Authorization: `Bearer ${token}` },
                });
                setAlert({ open: true, message: 'Category deleted successfully!', severity: 'success' });
                fetchCategories();
            }
        } catch (error) {
            console.error('Error deleting item:', error);
            setAlert({ open: true, message: `Error deleting ${deleteItem.type}!`, severity: 'error' });
        } finally {
            setConfirmOpen(false);
        }
    };

    const handleDeleteConfirmation = (id, type) => {
        setDeleteItem({ id, type });
        setConfirmOpen(true);
    };

    const handleCloseConfirm = () => {
        setConfirmOpen(false);
    };

    const handleCloseAlert = () => {
        setAlert({ ...alert, open: false });
    };

    const subcategoryColumns = [
        { field: 'id', headerName: 'ID', width: 90 },
        {
            field: 'subcategory_name',
            headerName: 'Subcategory Name',
            width: 150,
            editable: true,
        },
        {
            field: 'created_at',
            headerName: 'Created At',
            width: 200,
            renderCell: (params) => {
                if (!params.value) return 'N/A';
                const date = format(new Date(params.value), 'yyyy-MM-dd');
                const time = format(new Date(params.value), 'HH:mm:ss');
                return (
                    <div>
                        {date} <span style={{ color: 'rgba(0, 0, 0, 0.6)' }}>{time}</span>
                    </div>
                );
            },
        },
        {
            field: 'updated_at',
            headerName: 'Updated At',
            width: 200,
            renderCell: (params) => {
                if (!params.value) return 'N/A';
                const date = format(new Date(params.value), 'yyyy-MM-dd');
                const time = format(new Date(params.value), 'HH:mm:ss');
                return (
                    <div>
                        {date} <span style={{ color: 'rgba(0, 0, 0, 0.6)' }}>{time}</span>
                    </div>
                );
            },
        },
        {
            field: 'actions',
            headerName: 'Actions',
            width: 150,
            renderCell: (params) => (
                <>
                    <IconButton size="small" onClick={() => handleOpenSubcategoryModal(params.row)}>
                        <EditIcon />
                    </IconButton>
                    <IconButton size="small" onClick={() => handleDeleteConfirmation(params.row.id, 'subcategory')}>
                        <DeleteIcon />
                    </IconButton>
                </>
            ),
        },
    ];

    const categoryColumns = [
        { field: 'id', headerName: 'ID', width: 90 },
        { field: 'category_name', headerName: 'Category Name', width: 150 },
        {
            field: 'created_at',
            headerName: 'Created At',
            width: 200,
            renderCell: (params) => {
                if (!params.value) return 'N/A';
                const date = format(new Date(params.value), 'yyyy-MM-dd');
                const time = format(new Date(params.value), 'HH:mm:ss');
                return (
                    <div>
                        {date} <span style={{ color: 'rgba(0, 0, 0, 0.6)' }}>{time}</span>
                    </div>
                );
            },
        },
        {
            field: 'updated_at',
            headerName: 'Updated At',
            width: 200,
            renderCell: (params) => {
                if (!params.value) return 'N/A';
                const date = format(new Date(params.value), 'yyyy-MM-dd');
                const time = format(new Date(params.value), 'HH:mm:ss');
                return (
                    <div>
                        {date} <span style={{ color: 'rgba(0, 0, 0, 0.6)' }}>{time}</span>
                    </div>
                );
            },
        },
        {
            field: 'actions',
            headerName: 'Actions',
            width: 150,
            renderCell: (params) => (
                <>
                    <IconButton size="small" onClick={() => handleOpenCategoryModal(params.row)}>
                        <EditIcon />
                    </IconButton>
                    <IconButton size="small" onClick={() => handleDeleteConfirmation(params.row.id, 'category')}>
                        <DeleteIcon />
                    </IconButton>
                </>
            ),
        },
    ];

    return (
        <Box m={4}>
            <Grid container spacing={2}>
                <Grid item xs={9}>
                    <div style={{ height: 330, width: '100%' }}>
                        <DataGrid
                            rows={subcategories}
                            columns={subcategoryColumns}
                            pageSize={5}
                            rowsPerPageOptions={[5]}
                            checkboxSelection
                        />
                    </div>
                </Grid>
                <Grid item xs={3} container alignItems="center" justifyContent="center">
                    <Button variant="contained" color="primary" onClick={() => handleOpenSubcategoryModal()}>
                        Add Subcategory
                    </Button>
                </Grid>

                <Grid item xs={9}>
                    <div style={{ height: 330, width: '100%' }}>
                        <DataGrid
                            rows={categories}
                            columns={categoryColumns}
                            pageSize={5}
                            rowsPerPageOptions={[5]}
                            checkboxSelection
                        />
                    </div>
                </Grid>
                <Grid item xs={3} container alignItems="center" justifyContent="center">
                    <Button variant="contained" color="primary" onClick={() => handleOpenCategoryModal()}>
                        Add Category
                    </Button>
                </Grid>
            </Grid>
            <Snackbar
                open={alert.open}
                autoHideDuration={6000}
                onClose={handleCloseAlert}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
            >
                <Alert onClose={handleCloseAlert} severity={alert.severity}>
                    {alert.message}
                </Alert>
            </Snackbar>
            <Dialog
                open={confirmOpen}
                onClose={handleCloseConfirm}
                aria-labelledby="confirm-dialog-title"
                aria-describedby="confirm-dialog-description"
            >
                <DialogTitle id="confirm-dialog-title">{"Confirm Delete"}</DialogTitle>
                <DialogContent>
                    <Typography variant="body1">
                        Are you sure you want to delete this {deleteItem.type}?
                    </Typography>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseConfirm} color="primary">
                        Cancel
                    </Button>
                    <Button onClick={handleDeleteItem} color="primary" autoFocus>
                        Delete
                    </Button>
                </DialogActions>
            </Dialog>
            {isSubcategoryModalOpen && (
                <SubcategoryFormModal
                    open={isSubcategoryModalOpen}
                    handleClose={handleCloseSubcategoryModal}
                    fetchSubcategories={fetchSubcategories}
                    subcategory={selectedSubcategory}
                    categories={categories} // Pass categories to the SubcategoryFormModal
                    onSuccess={(message, severity) => setAlert({ open: true, message, severity })}
                />
            )}
            {isCategoryModalOpen && (
                <CategoryFormModal
                    open={isCategoryModalOpen}
                    handleClose={handleCloseCategoryModal}
                    fetchCategories={fetchCategories}
                    category={selectedCategory}
                    onSuccess={(message, severity) => setAlert({ open: true, message, severity })}
                />
            )}
        </Box>
    );
};

export default AddCategoryAndSubcategory;