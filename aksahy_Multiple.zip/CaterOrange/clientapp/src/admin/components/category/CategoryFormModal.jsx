import React, { useEffect, useState } from 'react';
import axios from 'axios';
import {
    Dialog, DialogTitle, DialogContent, DialogActions,
    TextField, Button, Snackbar, Alert, Grid
} from '@mui/material';

const CategoryFormModal = ({ open, handleClose, fetchCategories, category, onSuccess }) => {
    const [categoryName, setCategoryName] = useState('');
    const [alert, setAlert] = useState({ open: false, message: '', severity: 'success' });

    useEffect(() => {
        if (category) {
            setCategoryName(category.category_name);
        } else {
            setCategoryName('');
        }
    }, [category]);

    const handleChange = (e) => {
        setCategoryName(e.target.value);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const token = localStorage.getItem('token');
        try {
            if (category) {
                await axios.put(`http://localhost:9000/api/categories/${category.id}`, {
                    category_name: categoryName
                }, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });
                setAlert({ open: true, message: 'Category updated successfully!', severity: 'success' });
            } else {
                await axios.post('http://localhost:9000/api/categories', {
                    category_name: categoryName
                }, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });
                setAlert({ open: true, message: 'Category added successfully!', severity: 'success' });
            }
            fetchCategories();
            handleClose();
            onSuccess('Category added/updated successfully!', 'success');
        } catch (error) {
            console.error('Error creating/updating category:', error);
            setAlert({ open: true, message: 'Error creating/updating category!', severity: 'error' });
            onSuccess('Error creating/updating category!', 'error');
        }
    };

    const handleCloseAlert = () => {
        setAlert({ ...alert, open: false });
    };

    return (
        <Dialog
            open={open}
            onClose={() => {
                handleClose();
                setAlert({ open: false, message: '', severity: 'success' });
            }}
            maxWidth="xl"
            fullWidth
            PaperProps={{
                style: {
                    minHeight: '80vh',
                    maxHeight: '90vh',
                }
            }}
        >
            <DialogTitle style={{ marginTop: '35px', color: 'blue', fontWeight: 'bold', textAlign: 'left' }}>
                {category ? 'Update Category' : 'Add Category'}
            </DialogTitle>
            <DialogContent dividers style={{ paddingTop: '50px', textAlign: 'center', paddingLeft: '60px', paddingRight: '60px' }}>
                <form onSubmit={handleSubmit}>
                    <Grid container spacing={5} justifyContent="center" textAlign="center">
                        <Grid item xs={12}>
                            <TextField
                                margin="dense"
                                required
                                fullWidth
                                id="category_name"
                                label="Category Name"
                                name="category_name"
                                value={categoryName}
                                onChange={handleChange}
                                variant="outlined"
                                InputLabelProps={{ shrink: true }}
                            />
                        </Grid>
                    </Grid>
                    <Snackbar
                        open={alert.open}
                        autoHideDuration={6000}
                        onClose={handleCloseAlert}
                        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
                    >
                        <Alert onClose={handleCloseAlert} severity={alert.severity} sx={{ width: '100%' }}>
                            {alert.message}
                        </Alert>
                    </Snackbar>
                    <DialogActions style={{ justifyContent: 'flex-end', padding: '20px 60px', marginTop: '200px' }}>
                        <Button
                            onClick={handleClose}
                            color="primary"
                            size="large"
                        >
                            Cancel
                        </Button>
                        <Button
                            type="submit"
                            color="primary"
                            size="large"
                        >
                            {category ? 'Update Category' : 'Add Category'}
                        </Button>
                    </DialogActions>
                </form>
            </DialogContent>
        </Dialog>
    );
};

export default CategoryFormModal;



////// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import {
//     Dialog, DialogTitle, DialogContent, DialogActions,
//     TextField, Button, IconButton, Snackbar, Alert, Grid,
//     FormControl, InputLabel, Select, MenuItem
// } from '@mui/material';
// import CloseIcon from '@mui/icons-material/Close';

// const CategoryFormModal = ({ open, handleClose, fetchCategories, category, onSuccess }) => {
//     const [categoryName, setCategoryName] = useState('');
//     const [selectedSubcategoryId, setSelectedSubcategoryId] = useState('');
//     const [subcategories, setSubcategories] = useState([]);
//     const [alert, setAlert] = useState({ open: false, message: '', severity: 'success' });

//     useEffect(() => {
//         if (category) {
//             setCategoryName(category.category_name);
//             setSelectedSubcategoryId(category.subcategory_id || '');
//         } else {
//             setCategoryName('');
//             setSelectedSubcategoryId('');
//         }
//         fetchSubcategories();
//     }, [category]);

//     const handleChange = (e) => {
//         setCategoryName(e.target.value);
//     };

//     const handleSubcategoryChange = (e) => {
//         setSelectedSubcategoryId(e.target.value);
//     };

//     const handleSubmit = async (e) => {
//         e.preventDefault();
//         const token = localStorage.getItem('token');
//         try {
//             if (category) {
//                 await axios.put(`http://localhost:9000/api/categories/${category.id}`, {
//                     category_name: categoryName,
//                     subcategory_id: selectedSubcategoryId
//                 }, {
//                     headers: {
//                         Authorization: `Bearer ${token}`,
//                     },
//                 });
//                 setAlert({ open: true, message: 'Category updated successfully!', severity: 'success' });
//             } else {
//                 await axios.post('http://localhost:9000/api/categories', {
//                     category_name: categoryName,
//                     subcategory_id: selectedSubcategoryId
//                 }, {
//                     headers: {
//                         Authorization: `Bearer ${token}`,
//                     },
//                 });
//                 setAlert({ open: true, message: 'Category added successfully!', severity: 'success' });
//             }
//             fetchCategories();
//             handleClose();
//             onSuccess('Category added/updated successfully!', 'success');
//         } catch (error) {
//             console.error('Error creating/updating category:', error);
//             setAlert({ open: true, message: 'Error creating/updating category!', severity: 'error' });
//             onSuccess('Error creating/updating category!', 'error');
//         }
//     };

//     const handleCloseAlert = () => {
//         setAlert({ ...alert, open: false });
//     };

//     const fetchSubcategories = async () => {
//         const token = localStorage.getItem('token');
//         try {
//             const response = await axios.get('http://localhost:9000/api/subcategories', {
//                 headers: {
//                     Authorization: `Bearer ${token}`,
//                 },
//             });
//             setSubcategories(response.data);
//         } catch (error) {
//             console.error('Error fetching subcategories:', error);
//         }
//     };

//     return (
//         <Dialog
//             open={open}
//             onClose={() => {
//                 handleClose();
//                 setAlert({ open: false, message: '', severity: 'success' });
//             }}
//             maxWidth="xl"
//             fullWidth
//             PaperProps={{
//                 style: {
//                     minHeight: '80vh',
//                     maxHeight: '90vh',
//                 }
//             }}
//         >
//             <DialogTitle style={{ marginTop: '35px', color: 'blue', fontWeight: 'bold', textAlign: 'left' }}>
//                 {category ? 'Update Category' : 'Add Category'}
//             </DialogTitle>
//             {/* <IconButton onClick={handleClose} style={{ position: 'absolute', top: '10px', right: '10px' }}>
//                 <CloseIcon />
//             </IconButton> */}
//             <DialogContent dividers style={{ paddingTop: '50px', textAlign: 'center', paddingLeft: '60px', paddingRight: '60px' }}>
//                 <form onSubmit={handleSubmit}>
//                     <Grid container spacing={5} justifyContent="center" textAlign="center">
//                         <Grid item xs={12}>
//                             <TextField
//                                 margin="dense"
//                                 required
//                                 fullWidth
//                                 id="category_name"
//                                 label="Category Name"
//                                 name="category_name"
//                                 value={categoryName}
//                                 onChange={handleChange}
//                                 variant="outlined"
//                                 InputLabelProps={{ shrink: true }}
//                             />
//                         </Grid>
//                         <Grid item xs={12}>
//                             <FormControl fullWidth margin="dense">
//                                 <InputLabel id="subcategory-select-label">Subcategory</InputLabel>
//                                 <Select
//                                     labelId="subcategory-select-label"
//                                     id="subcategory-select"
//                                     value={selectedSubcategoryId}
//                                     onChange={handleSubcategoryChange}
//                                     variant="outlined"
//                                     label="Subcategory"
//                                 >
//                                     {subcategories.map((subcategory) => (
//                                         <MenuItem key={subcategory.id} value={subcategory.id}>
//                                             {subcategory.subcategory_type}
//                                         </MenuItem>
//                                     ))}
//                                 </Select>
//                             </FormControl>
//                         </Grid>
//                     </Grid>
//                     <Snackbar
//                         open={alert.open}
//                         autoHideDuration={6000}
//                         onClose={handleCloseAlert}
//                         anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
//                     >
//                         <Alert onClose={handleCloseAlert} severity={alert.severity} sx={{ width: '100%' }}>
//                             {alert.message}
//                         </Alert>
//                     </Snackbar>
//                     <DialogActions style={{ justifyContent: 'flex-end', padding: '20px 60px', marginTop: '200px' }}>
//                         <Button
//                             onClick={handleClose}
//                             color="primary"
//                             size="large"
//                         >
//                             Cancel
//                         </Button>
//                         <Button
//                             type="submit"
//                             color="primary"
//                             size="large"
//                         >
//                             {category ? 'Update Category' : 'Add Category'}
//                         </Button>
//                     </DialogActions>
//                 </form>
//             </DialogContent>
//         </Dialog>
//     );
// };

// export default CategoryFormModal;



// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import {
//     Dialog, DialogTitle, DialogContent, DialogActions,
//     TextField, Button, IconButton, Snackbar, Alert, Grid,
//     FormControl, InputLabel, Select, MenuItem
// } from '@mui/material';
// import CloseIcon from '@mui/icons-material/Close';

// const CategoryFormModal = ({ open, handleClose, fetchCategories, category }) => {
//     const [categoryName, setCategoryName] = useState('');
//     const [selectedSubcategoryId, setSelectedSubcategoryId] = useState('');
//     const [subcategories, setSubcategories] = useState([]);
//     const [alert, setAlert] = useState({ open: false, message: '', severity: 'success' });

//     useEffect(() => {
//         if (category) {
//             setCategoryName(category.category_name);
//             setSelectedSubcategoryId(category.subcategory_id || '');
//         } else {
//             setCategoryName('');
//             setSelectedSubcategoryId('');
//         }
//         fetchSubcategories();
//     }, [category]);

//     const handleChange = (e) => {
//         setCategoryName(e.target.value);
//     };

//     const handleSubcategoryChange = (e) => {
//         setSelectedSubcategoryId(e.target.value);
//     };

//     const handleSubmit = async (e) => {
//         e.preventDefault();
//         const token = localStorage.getItem('token');
//         try {
//             if (category) {
//                 await axios.put(`http://localhost:9000/api/categories/${category.id}`, {
//                     category_name: categoryName,
//                     subcategory_id: selectedSubcategoryId
//                 }, {
//                     headers: {
//                         Authorization: `Bearer ${token}`,
//                     },
//                 });
//                 setAlert({ open: true, message: 'Category updated successfully!', severity: 'success' });
//             } else {
//                 await axios.post('http://localhost:9000/api/categories', {
//                     category_name: categoryName,
//                     subcategory_id: selectedSubcategoryId
//                 }, {
//                     headers: {
//                         Authorization: `Bearer ${token}`,
//                     },
//                 });
//                 setAlert({ open: true, message: 'Category added successfully!', severity: 'success' });
//             }
//             handleClose();
//             fetchCategories();
//         } catch (error) {
//             console.error('Error creating/updating category:', error);
//             setAlert({ open: true, message: 'Error creating/updating category!', severity: 'error' });
//         }
//     };

//     const handleCloseAlert = () => {
//         setAlert({ ...alert, open: false });
//     };

//     const fetchSubcategories = async () => {
//         const token = localStorage.getItem('token');
//         try {
//             const response = await axios.get('http://localhost:9000/api/subcategories', {
//                 headers: {
//                     Authorization: `Bearer ${token}`,
//                 },
//             });
//             setSubcategories(response.data);
//         } catch (error) {
//             console.error('Error fetching subcategories:', error);
//         }
//     };

//     return (
//         <Dialog
//             open={open}
//             onClose={() => {
//                 handleClose();
//                 setAlert({ open: false, message: '', severity: 'success' });
//             }}
//             maxWidth="xl"
//             fullWidth
//             PaperProps={{
//                 style: {
//                     minHeight: '80vh',
//                     maxHeight: '90vh',
//                 }
//             }}
//         >
//             <DialogTitle style={{ marginTop: '35px', color: 'blue', fontWeight: 'bold', textAlign: 'center' }}>
//                 {category ? 'Update Category' : 'Add Category'}
//             </DialogTitle>
//             <IconButton onClick={handleClose} style={{ position: 'absolute', top: '10px', right: '10px' }}>
//                 <CloseIcon />
//             </IconButton>
//             <DialogContent dividers style={{ paddingTop: '50px', textAlign: 'center', paddingLeft: '60px', paddingRight: '60px' }}>
//                 <form onSubmit={handleSubmit}>
//                     <Grid container spacing={5} justifyContent="center" textAlign="center">
//                         <Grid item xs={12}>
//                             <TextField
//                                 margin="dense"
//                                 required
//                                 fullWidth
//                                 id="category_name"
//                                 label="Category Name"
//                                 name="category_name"
//                                 value={categoryName}
//                                 onChange={handleChange}
//                                 variant="outlined"
//                                 InputLabelProps={{ shrink: true }}
//                             />
//                         </Grid>
//                         <Grid item xs={12}>
//                             <FormControl fullWidth margin="dense">
//                                 <InputLabel id="subcategory-select-label">Subcategory</InputLabel>
//                                 <Select
//                                     labelId="subcategory-select-label"
//                                     id="subcategory-select"
//                                     value={selectedSubcategoryId}
//                                     onChange={handleSubcategoryChange}
//                                     variant="outlined"
//                                     label="Subcategory"
//                                 >
//                                     {subcategories.map((subcategory) => (
//                                         <MenuItem key={subcategory.id} value={subcategory.id}>
//                                             {subcategory.subcategory_type}
//                                         </MenuItem>
//                                     ))}
//                                 </Select>
//                             </FormControl>
//                         </Grid>
//                     </Grid>
//                     <Snackbar
//                         open={alert.open}
//                         autoHideDuration={6000}
//                         onClose={handleCloseAlert}
//                         anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
//                     >
//                         <Alert onClose={handleCloseAlert} severity={alert.severity} sx={{ width: '100%' }}>
//                             {alert.message}
//                         </Alert>
//                     </Snackbar>
//                     <DialogActions style={{ justifyContent: 'flex-end', padding: '20px 60px', marginTop: '200px' }}>
//                         <Button
//                             onClick={handleClose}
//                             color="primary"
//                             size="large"
//                         >
//                             Cancel
//                         </Button>
//                         <Button
//                             type="submit"
//                             color="primary"
//                             size="large"
//                         >
//                             {category ? 'Update Category' : 'Add Category'}
//                         </Button>
//                     </DialogActions>
//                 </form>
//             </DialogContent>
//         </Dialog>
//     );
// };

// export default CategoryFormModal;