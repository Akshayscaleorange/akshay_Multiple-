import React, { useEffect, useState } from 'react';
import axios from 'axios';
import {
  Button, Dialog, DialogActions, DialogContent, DialogTitle,
  TextField, Snackbar, Alert, Grid, FormControl, InputLabel, Select, MenuItem, Typography
} from '@mui/material';

const ProductFormModal = ({ open, handleClose, fetchProducts, product, handleAlert }) => {
  const [categories, setCategories] = useState([]);
  const [subcategories, setSubcategories] = useState([]);
  const [formData, setFormData] = useState({
    category_id: '',
    subcategory_id: '',
    product_name: '',
    quantity: '',
    description: '',
    price: '',
    images: null,
  });

  const [alert, setAlert] = useState({ open: false, message: '', severity: 'success' });
  const [fileName, setFileName] = useState('');

  useEffect(() => {
    const fetchCategories = async () => {
      const token = localStorage.getItem('token');
      try {
        const response = await axios.get('http://localhost:9000/api/categories', {
          headers: { Authorization: `Bearer ${token}` },
        });
        setCategories(response.data.categories);
      } catch (error) {
        console.error('Error fetching categories:', error);
        setAlert({ open: true, message: 'Error fetching categories!', severity: 'error' });
      }
    };

    const fetchSubcategories = async () => {
      const token = localStorage.getItem('token');
      try {
        const response = await axios.get('http://localhost:9000/api/subcategories', {
          headers: { Authorization: `Bearer ${token}` },
        });
        setSubcategories(response.data.subcategories);
      } catch (error) {
        console.error('Error fetching subcategories:', error);
        setAlert({ open: true, message: 'Error fetching subcategories!', severity: 'error' });
      }
    };

    fetchCategories();
    fetchSubcategories();
  }, []);

  useEffect(() => {
    if (product) {
      setFormData({
        category_id: product.category_id || '',
        subcategory_id: product.subcategory_id || '',
        product_name: product.product_name || '',
        quantity: product.quantity || '',
        description: product.description || '',
        price: product.price || '',
        images: null,
      });
      setFileName('');
    }
  }, [product]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleCategoryChange = (e) => {
    const categoryId = e.target.value;
    setFormData({
      ...formData,
      category_id: categoryId,
    });
  };

  const handleSubcategoryChange = (e) => {
    const subcategoryId = e.target.value;
    setFormData({
      ...formData,
      subcategory_id: subcategoryId,
    });
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setFormData({
      ...formData,
      images: file,
    });
    setFileName(file.name);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem('token');
    const data = new FormData();
    data.append('category_id', formData.category_id);
    data.append('subcategory_id', formData.subcategory_id);
    data.append('product_name', formData.product_name);
    data.append('quantity', formData.quantity);
    data.append('description', formData.description);
    data.append('price', formData.price);
    if (formData.images) {
      data.append('images', formData.images);
    }

    try {
      if (product) {
        // Update existing product
        await axios.put(`http://localhost:9000/api/products/${product.id}`, data, {
          headers: {
            'Content-Type': 'multipart/form-data',
            Authorization: `Bearer ${token}`,
          },
        });
        handleAlert('Product updated successfully!', 'success');
      } else {
        // Add new product
        await axios.post('http://localhost:9000/api/products', data, {
          headers: {
            'Content-Type': 'multipart/form-data',
            Authorization: `Bearer ${token}`,
          },
        });
        handleAlert('Product added successfully!', 'success');
      }
      handleClose();
      fetchProducts();
    } catch (error) {
      console.error('Error creating/updating product:', error);
      setAlert({ open: true, message: 'Error creating/updating product!', severity: 'error' });
    }
  };

  const handleCloseAlert = () => {
    setAlert({ ...alert, open: false });
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      maxWidth="xl"
      fullWidth
      PaperProps={{
        style: {
          minHeight: '80vh',
          maxHeight: '90vh',
        },
      }}
    >
      <DialogTitle style={{ marginTop: '35px', color: 'blue', fontWeight: 'bold' }}>
        {product ? 'Update Product' : 'Add Product'}
      </DialogTitle>
      <DialogContent dividers style={{ paddingTop: "50px", textAlign: "center", paddingLeft: "60px", paddingRight: "60px" }}>
        <form onSubmit={handleSubmit}>
          <Grid container spacing={5} justifyContent="center" textAlign="center">
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth margin="dense">
                <InputLabel id="category-select-label">Category</InputLabel>
                <Select
                  labelId="category-select-label"
                  id="category-select"
                  value={formData.category_id}
                  label="Category"
                  onChange={handleCategoryChange}
                >
                  {categories.map((category) => (
                    <MenuItem key={category.id} value={category.id}>
                      {category.category_name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth margin="dense">
                <InputLabel id="subcategory-select-label">Subcategory</InputLabel>
                <Select
                  labelId="subcategory-select-label"
                  id="subcategory-select"
                  value={formData.subcategory_id}
                  label="Subcategory"
                  onChange={handleSubcategoryChange}
                >
                  {subcategories.map((subcategory) => (
                    <MenuItem key={subcategory.id} value={subcategory.id}>
                      {subcategory.subcategory_name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                margin="dense"
                required
                fullWidth
                id="product_name"
                label="Product Name"
                name="product_name"
                autoComplete="product_name"
                value={formData.product_name}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                margin="dense"
                required
                fullWidth
                id="quantity"
                label="Quantity"
                name="quantity"
                autoComplete="quantity"
                value={formData.quantity}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                margin="dense"
                required
                fullWidth
                id="description"
                label="Description"
                name="description"
                autoComplete="description"
                value={formData.description}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                margin="dense"
                required
                fullWidth
                id="price"
                label="Price"
                name="price"
                autoComplete="price"
                value={formData.price}
                onChange={handleChange}
              />
            </Grid>
          </Grid>
          <Grid container spacing={5} justifyContent="flex-start" textAlign="center" sx={{ marginTop: '0' }}>
            <Grid item xs={12} sm={6}>
              <Button variant="contained" component="label" fullWidth>
                Upload Image
                <input type="file" hidden onChange={handleFileChange} />
              </Button>
              {fileName && (
                <Typography variant="body2" color="textSecondary" sx={{ marginTop: 2 }}>
                  Uploaded file: {fileName}
                </Typography>
              )}
            </Grid>
          </Grid>
          <DialogActions>
            <Button onClick={handleClose} color="primary" size="large">Cancel</Button>
            <Button type="submit" color="primary" size="large">{product ? 'Update Product' : 'Add Product'}</Button>
          </DialogActions>
        </form>
      </DialogContent>
      <Snackbar
        open={alert.open}
        autoHideDuration={6000}
        onClose={handleCloseAlert}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert onClose={handleCloseAlert} severity={alert.severity} sx={{ width: '100%' }}>
          {alert.message}
        </Alert>
      </Snackbar>
    </Dialog>
  );
};

export default ProductFormModal;


// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import {
//   Button, Dialog, DialogActions, DialogContent, DialogTitle,
//   TextField, Snackbar, Alert, Grid, FormControl, InputLabel, Select, MenuItem, Typography
// } from '@mui/material';

// const ProductFormModal = ({ open, handleClose, fetchProducts, product , handleAlert }) => {
//   const [categories, setCategories] = useState([]);
//   const [subcategories, setSubcategories] = useState([]);
//   const [formData, setFormData] = useState({
//     category_id: '',
//     subcategory_id: '',
//     product_name: '',
//     quantity: '',
//     description: '',
//     price: '',
//     images: null,
//   });

//   const [alert, setAlert] = useState({ open: false, message: '', severity: 'success' });
//   const [fileName, setFileName] = useState('');

//   useEffect(() => {
//     const fetchCategories = async () => {
//       const token = localStorage.getItem('token');
//       try {
//         const response = await axios.get('http://localhost:9000/api/categories', {
//           headers: { Authorization: `Bearer ${token}` },
//         });
//         setCategories(response.data);
//       } catch (error) {
//         console.error('Error fetching categories:', error);
//         setAlert({ open: true, message: 'Error fetching categories!', severity: 'error' });
//       }
//     };

//     const fetchSubcategories = async () => {
//       const token = localStorage.getItem('token');
//       try {
//         const response = await axios.get('http://localhost:9000/api/subcategories', {
//           headers: { Authorization: `Bearer ${token}` },
//         });
//         setSubcategories(response.data);
//       } catch (error) {
//         console.error('Error fetching subcategories:', error);
//         setAlert({ open: true, message: 'Error fetching subcategories!', severity: 'error' });
//       }
//     };

//     fetchCategories();
//     fetchSubcategories();
//   }, []);

//   useEffect(() => {
//     if (product) {
//       setFormData({
//         category_id: product.category_id || '',
//         subcategory_id: product.subcategory_id || '',
//         product_name: product.product_name || '',
//         quantity: product.quantity || '',
//         description: product.description || '',
//         price: product.price || '',
//         images: null,
//       });
//       setFileName('');
//     }
//   }, [product]);

//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     setFormData({
//       ...formData,
//       [name]: value,
//     });
//   };

//   const handleCategoryChange = (e) => {
//     const categoryId = e.target.value;
//     setFormData({
//       ...formData,
//       category_id: categoryId,
//     });
//   };

//   const handleSubcategoryChange = (e) => {
//     const subcategoryId = e.target.value;
//     setFormData({
//       ...formData,
//       subcategory_id: subcategoryId,
//     });
//   };

//   const handleFileChange = (e) => {
//     const file = e.target.files[0];
//     setFormData({
//       ...formData,
//       images: file,
//     });
//     setFileName(file.name);
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     const token = localStorage.getItem('token');
//     const data = new FormData();
//     data.append('category_id', formData.category_id);
//     data.append('subcategory_id', formData.subcategory_id);
//     data.append('product_name', formData.product_name);
//     data.append('quantity', formData.quantity);
//     data.append('description', formData.description);
//     data.append('price', formData.price);
//     if (formData.images) {
//       data.append('images', formData.images);
//     }

//     try {
//       if (product) {
//         // Update existing product
//         await axios.put(`http://localhost:9000/api/products/${product.id}`, data, {
//           headers: {
//             'Content-Type': 'multipart/form-data',
//             Authorization: `Bearer ${token}`,
//           },    
//         });
//         handleAlert('Product updated successfully!', 'success');
//         // setAlert({ open: true, message: 'Product updated successfully!', severity: 'success' });
//       } else {
//         // Add new product
//         await axios.post('http://localhost:9000/api/products', data, {
//           headers: {
//             'Content-Type': 'multipart/form-data',
//             Authorization: `Bearer ${token}`,
//           },
//         });
//         handleAlert('Product added successfully!', 'success');
//         // setAlert({ open: true, message: 'Product added successfully!', severity: 'success' });
//       }
//       handleClose();
//       fetchProducts();
//     } catch (error) {
//       console.error('Error creating/updating product:', error);
//       setAlert({ open: true, message: 'Error creating/updating product!', severity: 'error' });
//     }
//   };

//   const handleCloseAlert = () => {
//     setAlert({ ...alert, open: false });
//   };

//   return (
//     <Dialog
//       open={open}
//       onClose={handleClose}
//       maxWidth="xl"
//       fullWidth
//       PaperProps={{
//         style: {
//           minHeight: '80vh',
//           maxHeight: '90vh',
//         },
//       }}
//     >
//       <DialogTitle style={{ marginTop: '35px', color: 'blue', fontWeight: 'bold' }}>
//         {product ? 'Update Product' : 'Add Product'}
//       </DialogTitle>
//       <DialogContent dividers style={{ paddingTop: "50px", textAlign: "center", paddingLeft: "60px", paddingRight: "60px" }}>
//         <form onSubmit={handleSubmit}>
//           <Grid container spacing={5} justifyContent="center" textAlign="center">
//             <Grid item xs={12} sm={6}>
//               <FormControl fullWidth margin="dense">
//                 <InputLabel id="category-select-label">Category</InputLabel>
//                 <Select
//                   labelId="category-select-label"
//                   id="category-select"
//                   value={formData.category_id}
//                   label="Category"
//                   onChange={handleCategoryChange}
//                 >
//                   {categories.map((category) => (
//                     <MenuItem key={category.id} value={category.id}>
//                       {category.category_name}
//                     </MenuItem>
//                   ))}
//                 </Select>
//               </FormControl>
//             </Grid>
//             <Grid item xs={12} sm={6}>
//               <FormControl fullWidth margin="dense">
//                 <InputLabel id="subcategory-select-label">Subcategory</InputLabel>
//                 <Select
//                   labelId="subcategory-select-label"
//                   id="subcategory-select"
//                   value={formData.subcategory_id}
//                   label="Subcategory"
//                   onChange={handleSubcategoryChange}
//                 >
//                   {subcategories.map((subcategory) => (
//                     <MenuItem key={subcategory.id} value={subcategory.id}>
//                       {subcategory.subcategory_type}
//                     </MenuItem>
//                   ))}
//                 </Select>
//               </FormControl>
//             </Grid>
//             <Grid item xs={12} sm={6}>
//               <TextField
//                 margin="dense"
//                 required
//                 fullWidth
//                 id="product_name"
//                 label="Product Name"
//                 name="product_name"
//                 autoComplete="product_name"
//                 value={formData.product_name}
//                 onChange={handleChange}
//               />
//             </Grid>
//             <Grid item xs={12} sm={6}>
//               <TextField
//                 margin="dense"
//                 required
//                 fullWidth
//                 id="quantity"
//                 label="Quantity"
//                 name="quantity"
//                 autoComplete="quantity"
//                 value={formData.quantity}
//                 onChange={handleChange}
//               />
//             </Grid>
//             <Grid item xs={12} sm={6}>
//               <TextField
//                 margin="dense"
//                 required
//                 fullWidth
//                 id="description"
//                 label="Description"
//                 name="description"
//                 autoComplete="description"
//                 value={formData.description}
//                 onChange={handleChange}
//               />
//             </Grid>
//             <Grid item xs={12} sm={6}>
//               <TextField
//                 margin="dense"
//                 required
//                 fullWidth
//                 id="price"
//                 label="Price"
//                 name="price"
//                 autoComplete="price"
//                 value={formData.price}
//                 onChange={handleChange}
//               />
//             </Grid>
//           </Grid>
//           <Grid container spacing={5} justifyContent="flex-start" textAlign="center" sx={{ marginTop: '0' }}>
//             <Grid item xs={12} sm={6}>
//               <Button variant="contained" component="label" fullWidth>
//                 Upload Image
//                 <input type="file" hidden onChange={handleFileChange} />
//               </Button>
//               {fileName && (
//                 <Typography variant="body2" color="textSecondary" sx={{ marginTop: 2 }}>
//                   Uploaded file: {fileName}
//                 </Typography>
//               )}
//             </Grid>
//           </Grid>
//           <DialogActions>
//             <Button onClick={handleClose} color="primary" size="large">Cancel</Button>
//             <Button type="submit" color="primary" size="large">{product ? 'Update Product' : 'Add Product'}</Button>
//           </DialogActions>
//         </form>
//       </DialogContent>
//       <Snackbar
//         open={alert.open}
//         autoHideDuration={6000}
//         onClose={handleCloseAlert}
//         anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
//       >
//         <Alert onClose={handleCloseAlert} severity={alert.severity} sx={{ width: '100%' }}>
//           {alert.message}
//         </Alert>
//       </Snackbar>
//     </Dialog>
//   );
// };

// export default ProductFormModal;