import React, { useState, useEffect } from 'react';
import axios from 'axios';
import ProductFormModal from './ProductFormModel';
import {
  Button, Dialog, DialogActions, DialogContent, DialogTitle,
  Typography, Snackbar, Alert, IconButton
} from '@mui/material';
import { DataGrid } from '@mui/x-data-grid';
import VisibilityIcon from '@mui/icons-material/Visibility';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import { format } from 'date-fns';

const ProductCard = () => {
  const [products, setProducts] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [deleteProductId, setDeleteProductId] = useState(null);
  const [alert, setAlert] = useState({ open: false, message: '', severity: 'success' });
  const [detailOpen, setDetailOpen] = useState(false);

  const fetchProducts = async () => {
    try {
      const token = await localStorage.getItem('token');
      const response = await axios.get('http://localhost:9000/api/products', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      // Convert binary image data to base64
      const productsWithImages = response.data.products.map(product => {
        if (product.images && product.images.length > 0) {
          const base64String = product.images[0];
          product.imageSrc = `data:image/jpeg;base64,${base64String}`;
        }
        return product;
      });
      setProducts(productsWithImages);
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const handleModalOpen = (product = null) => {
    setSelectedProduct(product);
    setModalOpen(true);
  };

  const handleModalClose = () => {
    setSelectedProduct(null);
    setModalOpen(false);
  };

  const handleDetailOpen = (product) => {
    setSelectedProduct(product);
    setDetailOpen(true);
  };

  const handleDetailClose = () => {
    setSelectedProduct(null);
    setDetailOpen(false);
  };

  const handleDeleteProduct = async (productId) => {
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`http://localhost:9000/api/products/${productId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      fetchProducts();
      setAlert({ open: true, message: 'Product deleted successfully!', severity: 'success' });
    } catch (error) {
      console.error('Error deleting product:', error);
      setAlert({ open: true, message: 'Error deleting product!', severity: 'error' });
    } finally {
      setConfirmOpen(false);
    }
  };

  const handleConfirmClose = () => {
    setConfirmOpen(false);
  };

  const handleCloseAlert = () => {
    setAlert({ ...alert, open: false });
  };

  const handleAlert = (message, severity) => {
    setAlert({ open: true, message, severity });
  };


  const columns = [
    { field: 'id', headerName: 'ID', width: 50 },
    { field: 'product_name', headerName: 'Product Name', width: 150 },
    { field: 'description', headerName: 'Description', width: 250 },
    { field: 'quantity', headerName: 'Quantity', width: 110 },
    { field: 'price', headerName: 'Price', width: 110 },
    { field: 'coupon_id', headerName: 'coupon code', width: 110 },
    {
      field: 'created_at',
      headerName: 'Created At',
      width: 200,
      renderCell: (params) => {
        const date = format(new Date(params.row.created_at), 'yyyy-MM-dd');
        const time = format(new Date(params.row.created_at), 'HH:mm:ss');
        return (
          <div>
            {date} <span style={{ color: 'rgba(0, 0, 0, 0.6)' }}>{time}</span>
          </div>
        );
      }
    },
    {
      field: 'updated_at',
      headerName: 'Updated At',
      width: 200,
      renderCell: (params) => {
        const date = format(new Date(params.row.updated_at), 'yyyy-MM-dd');
        const time = format(new Date(params.row.updated_at), 'HH:mm:ss');
        return (
          <div>
            {date} <span style={{ color: 'rgba(0, 0, 0, 0.6)' }}>{time}</span>
          </div>
        );
      }
    },
    {
      field: 'actions',
      headerName: 'Actions',
      width: 180,
      renderCell: (params) => (
        <>
          <IconButton size="small" onClick={() => handleDetailOpen(params.row)}>
            <VisibilityIcon />
          </IconButton>
          <IconButton size="small" onClick={() => handleModalOpen(params.row)}>
            <EditIcon />
          </IconButton>
          <IconButton size="small" onClick={() => { setDeleteProductId(params.row.id); setConfirmOpen(true); }}>
            <DeleteIcon />
          </IconButton>
        </>
      ),
    },
  ];

  return (
    <div style={{ margin: '20px' }}>
      <Button variant="contained" color="primary" onClick={() => handleModalOpen()} style={{ marginBottom: '20px' }}>
        Add Product
      </Button>
      <div style={{ height: 700, width: '100%' }}>
        <DataGrid
          rows={products}
          columns={columns}
          initialState={{
            pagination: {
              paginationModel: { page: 0, pageSize: 5 },
            },
          }}
          pageSizeOptions={[5, 10]}
          checkboxSelection
        />
      </div>
      <ProductFormModal
        open={modalOpen}
        handleClose={handleModalClose}
        fetchProducts={fetchProducts}
        product={selectedProduct}
        handleAlert={handleAlert}
      />
      <Dialog
        open={confirmOpen}
        onClose={handleConfirmClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">{"Confirm Delete"}</DialogTitle>
        <DialogContent>
          <Typography variant="body1">
            Are you sure you want to delete this product?
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleConfirmClose} color="primary">
            Cancel
          </Button>
          <Button onClick={() => handleDeleteProduct(deleteProductId)} color="primary" autoFocus>
            Delete
          </Button>
        </DialogActions>
      </Dialog>
      <Dialog
        open={detailOpen}
        onClose={handleDetailClose}
        aria-labelledby="product-detail-title"
        aria-describedby="product-detail-description"
      >
        <DialogTitle id="product-detail-title">Product Details</DialogTitle>
        <DialogContent>
          {selectedProduct && (
            <>
              <Typography variant="h6">{selectedProduct.product_name}</Typography>
              <Typography variant="body1">Price: ${selectedProduct.price}</Typography>
              <Typography variant="body1">Quantity: {selectedProduct.quantity}</Typography>
              {selectedProduct.imageSrc && (
                <img src={selectedProduct.imageSrc} alt={selectedProduct.product_name} style={{ width: '100%', marginTop: '10px' }} />
              )}
              <Typography variant="body2" style={{ marginTop: '10px' }}>Description: {selectedProduct.description}</Typography>
            </>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleDetailClose} color="primary">
            Close
          </Button>
        </DialogActions>
      </Dialog>
      <Snackbar
        open={alert.open}
        autoHideDuration={6000}
        onClose={handleCloseAlert}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert onClose={handleCloseAlert} severity={alert.severity} sx={{ width: '100%' }}>
          {alert.message}
        </Alert>
      </Snackbar>
    </div>
  );
};

export default ProductCard;

