import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Button, Snackbar, Alert, IconButton, Dialog, DialogTitle, DialogContent, DialogActions, Typography, TextField } from '@mui/material';
import { DataGrid } from '@mui/x-data-grid';
import VisibilityIcon from '@mui/icons-material/Visibility';
import EditIcon from '@mui/icons-material/Edit';
import { format } from 'date-fns';

const RoleManagement = () => {
    const [roles, setRoles] = useState([]);
    const [alert, setAlert] = useState({ open: false, message: '', severity: 'success' });
    const [selectedRole, setSelectedRole] = useState(null);
    const [detailOpen, setDetailOpen] = useState(false);
    const [modalOpen, setModalOpen] = useState(false);
    const [editRoleName, setEditRoleName] = useState('');

    const fetchRoles = async () => {
        // try {
        //     const token = localStorage.getItem('token');
        //     const response = await axios.get('http://localhost:9000/api/getRoles', {
        //         headers: {
        //             Authorization: `Bearer ${token}`,
        //         },
        //     });
        //     setRoles(response.data);
        // } catch (error) {
        //     console.error('Error fetching roles:', error);
        // }
    };

    useEffect(() => {
        fetchRoles();
    }, []);

    const handleDetailOpen = (role) => {
        setSelectedRole(role);
        setDetailOpen(true);
    };

    const handleDetailClose = () => {
        setSelectedRole(null);
        setDetailOpen(false);
    };

    const handleModalOpen = (role) => {
        setSelectedRole(role);
        setEditRoleName(role.roles);
        setModalOpen(true);
    };

    const handleModalClose = () => {
        setSelectedRole(null);
        setModalOpen(false);
    };

    const handleCloseAlert = () => {
        setAlert({ ...alert, open: false });
    };

    const handleRoleNameChange = (event) => {
        setEditRoleName(event.target.value);
    };

    const handleSaveRole = async () => {
        try {
            const token = localStorage.getItem('token');
            const roleId = selectedRole.id;
            const updatedRoleData = {
                roles: editRoleName,
            };
            await axios.put(`http://localhost:9000/api/updateRole/${roleId}`, updatedRoleData, {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            });
            // Update roles state after successful update
            fetchRoles();
            setModalOpen(false);
            setAlert({ open: true, message: 'Role updated successfully', severity: 'success' });
        } catch (error) {
            console.error('Error updating role:', error);
            setAlert({ open: true, message: 'Failed to update role', severity: 'error' });
        }
    };

    const columns = [
        { field: 'id', headerName: 'ID', width: 100 },
        { field: 'roles', headerName: 'Role Name', width: 200 },
        {
            field: 'created_at',
            headerName: 'Created At',
            width: 350,
            renderCell: (params) => {
                const date = format(new Date(params.row.created_at), 'yyyy-MM-dd');
                const time = format(new Date(params.row.created_at), 'HH:mm:ss');
                return (
                    <div>
                        {date} <span style={{ color: 'rgba(0, 0, 0, 0.6)' }}>{time}</span>
                    </div>
                );
            }
        },
        {
            field: 'updated_at',
            headerName: 'Updated At',
            width: 350,
            renderCell: (params) => {
                const date = format(new Date(params.row.updated_at), 'yyyy-MM-dd');
                const time = format(new Date(params.row.updated_at), 'HH:mm:ss');
                return (
                    <div>
                        {date} <span style={{ color: 'rgba(0, 0, 0, 0.6)' }}>{time}</span>
                    </div>
                );
            }
        },
        {
            field: 'actions',
            headerName: 'Actions',
            sortable: false,
            width: 100,
            renderCell: (params) => (
                <div>
                    <IconButton size="small" onClick={() => handleDetailOpen(params.row)}>
                        <VisibilityIcon />
                    </IconButton>
                    <IconButton size="small" onClick={() => handleModalOpen(params.row)}>
                        <EditIcon />
                    </IconButton>
                </div>
            ),
        },
    ];

    return (
        <div style={{ marginLeft: 200, marginRight: 200, marginTop: 100 }}>
            <div style={{ height: 700, width: '80rem' }}>
                <DataGrid
                    rows={roles}
                    columns={columns}
                    pageSize={5}
                    checkboxSelection
                    autoHeight={false}
                    getRowId={(row) => row.id}
                />
            </div>
            <Dialog
                open={detailOpen}
                onClose={handleDetailClose}
                aria-labelledby="role-detail-title"
                aria-describedby="role-detail-description"
                fullWidth
                maxWidth="sm"
            >
                <DialogTitle id="role-detail-title" style={{ color: 'blue', fontWeight: 'bold' }}>Role Details</DialogTitle>
                <DialogContent style={{ minHeight: '300px', padding: '100px', border: '1px solid #ccc', borderRadius: '8px', alignItems: 'center' }}>
                    {selectedRole && (
                        <>
                            <Typography variant="h6">{selectedRole.roles}</Typography>
                            <Typography variant="body1">Created At: {new Date(selectedRole.created_at).toLocaleString()}</Typography>
                            <Typography variant="body1">Updated At: {new Date(selectedRole.updated_at).toLocaleString()}</Typography>
                        </>
                    )}
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleDetailClose} color="primary">
                        Close
                    </Button>
                </DialogActions>
            </Dialog>
            <Dialog
                open={modalOpen}
                onClose={handleModalClose}
                aria-labelledby="role-edit-title"
                aria-describedby="role-edit-description"
                fullWidth
                maxWidth="md"
            >
                <DialogTitle id="role-edit-title" style={{ color: 'blue', fontWeight: 'bold' }}>{selectedRole ? 'Edit Role' : 'Add Role'}</DialogTitle>
                <DialogContent style={{ minHeight: '300px', padding: '100px', borderRadius: '8px', textAlign: 'center' }}>
                    <TextField
                        autoFocus
                        margin="dense"
                        id="roleName"
                        label="Role Name"
                        type="text"
                        fullWidth
                        value={editRoleName}
                        onChange={handleRoleNameChange}
                    />
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleModalClose} color="primary" size='large'>
                        Cancel
                    </Button>
                    <Button onClick={handleSaveRole} color="primary" size='large'>
                        Save
                    </Button>
                </DialogActions>
            </Dialog>
            <Snackbar
                open={alert.open}
                autoHideDuration={6000}
                onClose={handleCloseAlert}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
            >
                <Alert onClose={handleCloseAlert} severity={alert.severity} sx={{ width: '100%' }}>
                    {alert.message}
                </Alert>
            </Snackbar>
        </div>
    );
};

export default RoleManagement;
