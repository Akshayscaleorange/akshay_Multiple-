import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Dialog, DialogTitle, DialogContent, DialogActions, Button, TextField, Grid } from '@mui/material';

const UserFormModal = ({ open, handleClose, fetchUsers, user }) => {
    const [formData, setFormData] = useState({
        firstname: '',
        lastname: '',
        email: '',
        password: '',
        confirm_password: '',
        address: '',
        phone_number: '',
        pincode: '',
        role_id: '',
        // accesstoken: ''
    });

    useEffect(() => {
        if (user) {
            setFormData(user);
        }
    }, [user]);

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const token = localStorage.getItem('token');
            const config = { headers: { Authorization: `Bearer ${token}` } };

            if (user) {
                await axios.put(`http://localhost:9000/api/users/${user.id}`, formData, config);
            } else {
                await axios.post('http://localhost:9000/api/users', formData, config);
            }
            fetchUsers();
            handleClose();
        } catch (error) {
            console.error('Error saving user:', error);
        }
    };

    return (
        <Dialog
            open={open}
            onClose={handleClose}
            maxWidth="xl" // Increased size
            fullWidth
            PaperProps={{
                style: {
                    minHeight: '80vh', // Minimum height
                    maxHeight: '90vh'  // Maximum height
                }
            }}
        >
            <DialogTitle style={{ marginTop: '35px', color: 'blue', fontWeight: 'bold' }}>{user ? 'Update User' : 'Add User'}</DialogTitle>
            <DialogContent dividers style={{ paddingTop: "50px", textAlign: "center", paddingLeft: "60px", paddingRight: "60px" }}>
                <form onSubmit={handleSubmit}>
                    <Grid container spacing={5} justifyContent="center" textAlign="center" >
                        <Grid item xs={12} sm={6}>
                            <TextField
                                required
                                fullWidth
                                margin="dense"
                                label="First Name"
                                name="firstname"
                                variant="outlined"
                                value={formData.firstname}
                                onChange={handleChange}
                            />
                        </Grid>
                        <Grid item xs={12} sm={6}>
                            <TextField
                                required
                                fullWidth
                                margin="dense"
                                label="Last Name"
                                name="lastname"
                                variant="outlined"
                                value={formData.lastname}
                                onChange={handleChange}
                            />
                        </Grid>

                        {!user && (
                            <>
                                <Grid item xs={12} sm={6}>
                                    <TextField
                                        required
                                        fullWidth
                                        margin="dense"
                                        label="Password"
                                        name="password"
                                        type="password"
                                        variant="outlined"
                                        value={formData.password}
                                        onChange={handleChange}
                                    />
                                </Grid>
                                <Grid item xs={12} sm={6}>
                                    <TextField
                                        required
                                        fullWidth
                                        margin="dense"
                                        label="Confirm Password"
                                        name="confirm_password"
                                        type="password"
                                        variant="outlined"
                                        value={formData.confirm_password}
                                        onChange={handleChange}
                                    />
                                </Grid>
                            </>
                        )}
                        <Grid item xs={12} sm={6}>
                            <TextField
                                required
                                fullWidth
                                margin="dense"
                                label="Email"
                                name="email"
                                variant="outlined"
                                value={formData.email}
                                onChange={handleChange}
                            />
                        </Grid>
                        <Grid item xs={12} sm={6}>
                            <TextField
                                fullWidth
                                margin="dense"
                                label="Address"
                                name="address"
                                variant="outlined"
                                value={formData.address}
                                onChange={handleChange}
                            />
                        </Grid>
                        <Grid item xs={12} sm={6}>
                            <TextField
                                fullWidth
                                margin="dense"
                                label="Phone Number"
                                name="phone_number"
                                variant="outlined"
                                value={formData.phone_number}
                                onChange={handleChange}
                            />
                        </Grid>
                        <Grid item xs={12} sm={6}>
                            <TextField
                                fullWidth
                                margin="dense"
                                label="Pincode"
                                name="pincode"
                                variant="outlined"
                                value={formData.pincode}
                                onChange={handleChange}
                            />
                        </Grid>
                        <Grid item xs={12} sm={6}>
                            <TextField
                                fullWidth
                                margin="dense"
                                label="Role ID"
                                name="role_id"
                                variant="outlined"
                                value={formData.role_id}
                                onChange={handleChange}
                            />
                        </Grid>
                    </Grid>
                    <DialogActions>
                        <Button onClick={handleClose} color="primary" size="large">Cancel</Button>
                        <Button type="submit" color="primary" size="large">Save</Button>
                    </DialogActions>
                </form>
            </DialogContent>
        </Dialog>
    );
};

export default UserFormModal;
