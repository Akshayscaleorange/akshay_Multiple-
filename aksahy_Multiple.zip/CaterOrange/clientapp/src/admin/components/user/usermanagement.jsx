import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { DataGrid } from '@mui/x-data-grid';
import { Button, Dialog, DialogTitle, DialogContent, DialogActions, Snackbar, Alert, IconButton, Typography, Box } from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import VisibilityIcon from '@mui/icons-material/Visibility';
import { format } from 'date-fns';
import UserFormModal from './userFormModal';

const Users = () => {
    const [users, setUsers] = useState([]);
    const [modalOpen, setModalOpen] = useState(false);
    const [selectedUser, setSelectedUser] = useState(null);
    const [confirmOpen, setConfirmOpen] = useState(false);
    const [deleteUserId, setDeleteUserId] = useState(null);
    const [viewUser, setViewUser] = useState(null);
    const [alert, setAlert] = useState({ open: false, message: '', severity: 'success' });
    const [pagination, setPagination] = useState({ page: 1, pageSize: 10, totalItems: 0 });

    const fetchUsers = async () => {
        try {
            const token = localStorage.getItem('token');
            const response = await axios.get(`http://localhost:9000/api/users?page=${pagination.page}&pageSize=${pagination.pageSize}`, {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            });
            setUsers(response.data.users);
            setPagination({
                ...pagination,
                totalItems: response.data.totalUsers,
            });
        } catch (error) {
            console.error('Error fetching users:', error);
        }
    };

    useEffect(() => {
        fetchUsers();
    }, [pagination.page, pagination.pageSize]); // Refresh users when pagination changes

    const handleModalOpen = (user = null) => {
        setSelectedUser(user);
        setModalOpen(true);
    };

    const handleModalClose = () => {
        setSelectedUser(null);
        setModalOpen(false);
    };

    const handleDeleteUser = async (userId) => {
        try {
            const token = localStorage.getItem('token');
            await axios.delete(`http://localhost:9000/api/users/${userId}`, {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            });
            fetchUsers();
            setAlert({ open: true, message: 'User deleted successfully!', severity: 'success' });
        } catch (error) {
            console.error('Error deleting user:', error);
            setAlert({ open: true, message: 'Error deleting user!', severity: 'error' });
        } finally {
            setConfirmOpen(false);
        }
    };

    const handleConfirmClose = () => {
        setConfirmOpen(false);
    };

    const handleCloseAlert = () => {
        setAlert({ ...alert, open: false });
    };

    const handleViewUserOpen = (user) => {
        setViewUser(user);
        // Implement view user logic as needed
    };

    const handleViewUserClose = () => {
        setViewUser(null);
        // Implement view user close logic as needed
    };

    const columns = [
        { field: 'id', headerName: 'ID', width: 100 },
        { field: 'firstname', headerName: 'First name', width: 150 },
        { field: 'lastname', headerName: 'Last name', width: 150 },
        { field: 'email', headerName: 'Email', width: 200 },
        { field: 'role_id', headerName: 'Role ID', width: 100 },
        { field: 'phone_number', headerName: 'Phone Number', width: 150 },
        { field: 'pincode', headerName: 'Pincode', width: 150 },
        {
            field: 'created_at',
            headerName: 'Created At',
            width: 200,
            renderCell: (params) => {
                const date = format(new Date(params.row.created_at), 'yyyy-MM-dd');
                const time = format(new Date(params.row.created_at), 'HH:mm:ss');
                return (
                    <div>
                        {date} <span style={{ color: 'rgba(0, 0, 0, 0.6)' }}>{time}</span>
                    </div>
                );
            }
        },
        {
            field: 'updated_at',
            headerName: 'Updated At',
            width: 200,
            renderCell: (params) => {
                const date = format(new Date(params.row.updated_at), 'yyyy-MM-dd');
                const time = format(new Date(params.row.updated_at), 'HH:mm:ss');
                return (
                    <div>
                        {date} <span style={{ color: 'rgba(0, 0, 0, 0.6)' }}>{time}</span>
                    </div>
                );
            }
        },
        {
            field: 'actions',
            headerName: 'Actions',
            sortable: false,
            width: 200,
            renderCell: (params) => (
                <div>
                    <IconButton
                        color="info"
                        onClick={() => handleViewUserOpen(params.row)}
                    >
                        <VisibilityIcon />
                    </IconButton>
                    <IconButton
                        color="primary"
                        onClick={() => handleModalOpen(params.row)}
                    >
                        <EditIcon />
                    </IconButton>
                    <IconButton
                        color="secondary"
                        onClick={() => {
                            setConfirmOpen(true);
                            setDeleteUserId(params.row.id);
                        }}
                    >
                        <DeleteIcon />
                    </IconButton>
                </div>
            ),
        },
    ];

    const handlePageChange = (newPage) => {
        setPagination({ ...pagination, page: newPage });
    };

    const handlePageSizeChange = (pageSize) => {
        setPagination({ ...pagination, pageSize, page: 1 });
    };

    return (
        <div style={{ margin: 50 }}>
            <Button variant="contained" color="primary" onClick={() => handleModalOpen()} sx={{ margin: 2 }}>
                Add User
            </Button>
            <div style={{ height: 700, width: '100%' }}>
                <DataGrid
                    rows={users}
                    columns={columns}
                    pagination
                    pageSize={pagination.pageSize}
                    rowCount={pagination.totalItems}
                    paginationMode="server"
                    onPageChange={handlePageChange}
                    pageSizeOptions={[5, 10, 50, 100]}
                    autoHeight={false}
                    getRowId={(row) => row.id}
                    loading={users.length === 0} // You might want to add a loading indicator here
                />
            </div>
            <UserFormModal
                open={modalOpen}
                handleClose={handleModalClose}
                fetchUsers={fetchUsers}
                user={selectedUser}
            />
            <Dialog
                open={confirmOpen}
                onClose={handleConfirmClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <DialogTitle id="alert-dialog-title">{"Confirm Delete"}</DialogTitle>
                <DialogContent>
                    Are you sure you want to delete this user?
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleConfirmClose} color="primary">
                        Cancel
                    </Button>
                    <Button onClick={() => handleDeleteUser(deleteUserId)} color="primary" autoFocus>
                        Delete
                    </Button>
                </DialogActions>
            </Dialog>
            <Dialog
                open={!!viewUser}
                onClose={handleViewUserClose}
                aria-labelledby="user-details-dialog-title"
                maxWidth="md"
                fullWidth
            >
                <DialogTitle id="user-details-dialog-title" style={{ color: 'blue', fontWeight: 'bold' }}>User Details</DialogTitle>
                <DialogContent dividers style={{ padding: '3rem' }}>
                    {viewUser && (
                        <Box>
                            <Typography variant="h6" gutterBottom>
                                {viewUser.firstname} {viewUser.lastname}
                            </Typography>
                            <Typography variant="body1">
                                <strong>Email:</strong> {viewUser.email}
                            </Typography>
                            <Typography variant="body1">
                                <strong>Role ID:</strong> {viewUser.role_id}
                            </Typography>
                            {/* <Typography variant="body1">
                                <strong>Address:</strong> {viewUser.address}
                            </Typography> */}
                            <Typography variant="body1">
                                <strong>Phone Number:</strong> {viewUser.phone_number}
                            </Typography>
                            <Typography variant="body1">
                                <strong>Pincode:</strong> {viewUser.pincode}
                            </Typography>
                        </Box>
                    )}
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleViewUserClose} color="primary" size="large">
                        Close
                    </Button>
                </DialogActions>
            </Dialog>
            <Snackbar open={alert.open} autoHideDuration={6000} onClose={handleCloseAlert}>
                <Alert onClose={handleCloseAlert} severity={alert.severity}>
                    {alert.message}
                </Alert>
            </Snackbar>
        </div>
    );
};

export default Users;
