import React from 'react';

export default function Footer() {
  return (
    <div>
      <div className="row-fluid">
        <div id="footer" className="span12"> 2024 &copy; CaterOranage Admin. Brought to you by </div>
      </div>
    </div>
  );
}
