import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {
  Button, Dialog, DialogActions, DialogContent, DialogTitle,
  Typography, Snackbar, Alert, IconButton, Pagination, Box
} from '@mui/material';
import { DataGrid } from '@mui/x-data-grid';
import VisibilityIcon from '@mui/icons-material/Visibility';
import DeleteIcon from '@mui/icons-material/Delete';
import { format } from 'date-fns';

const OrderCard = () => {
  const [orders, setOrders] = useState([]);
  const [detailOpen, setDetailOpen] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [deleteOrderId, setDeleteOrderId] = useState(null);
  const [alert, setAlert] = useState({ open: false, message: '', severity: 'success' });
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(0);
  const pageSize = 5;

  useEffect(() => {
    fetchOrders(currentPage);
  }, [currentPage]);

  const fetchOrders = async (page) => {
    try {
      const token = await localStorage.getItem('token');
      const response = await axios.get('http://localhost:9000/api/getOrders', {
        headers: {
          'Authorization': `Bearer ${token}`
        },
        params: {
          page,
          pageSize,
        }
      });
      const { orders, totalPages, currentPage } = response.data;
      const formattedOrders = orders.map(order => ({
        order_id: order.id,
        customer_name: `${order.User.firstname} ${order.User.lastname}`,
        status: order.payment_status,
        total: order.TotalPrice,
        order_date: order.created_at,
        customer: order.User,
        items: order.OrderItems,
      }));
      setOrders(formattedOrders);
      setCurrentPage(currentPage);
      setTotalPages(totalPages);
    } catch (error) {
      console.error('Error fetching orders:', error);
    }
  };

  const handleDetailOpen = (order) => {
    setSelectedOrder(order);
    setDetailOpen(true);
  };

  const handleDetailClose = () => {
    setSelectedOrder(null);
    setDetailOpen(false);
  };

  const handleDeleteOrder = async (orderId) => {
    try {
      // Assuming you have an API endpoint to delete the order
      await axios.delete(`http://localhost:9000/api/orders/${orderId}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      const updatedOrders = orders.filter(order => order.order_id !== orderId);
      setOrders(updatedOrders);
      setAlert({ open: true, message: 'Order deleted successfully!', severity: 'success' });
    } catch (error) {
      console.error('Error deleting order:', error);
      setAlert({ open: true, message: 'Error deleting order!', severity: 'error' });
    } finally {
      setConfirmOpen(false);
    }
  };

  const handleConfirmClose = () => {
    setConfirmOpen(false);
  };

  const handleCloseAlert = () => {
    setAlert({ ...alert, open: false });
  };

  const handlePageChange = (event, value) => {
    setCurrentPage(value);
  };

  const columns = [
    { field: 'order_id', headerName: 'Order ID', width: 100 },
    {
      field: 'customer_name',
      headerName: 'Customer Name',
      width: 150,
    },
    { field: 'status', headerName: 'Status', width: 120 },
    { field: 'total', headerName: 'Total', width: 100 },
    {
      field: 'order_date',
      headerName: 'Order Date',
      width: 200,
      renderCell: (params) => format(new Date(params.value), 'yyyy-MM-dd HH:mm:ss')
    },
    {
      field: 'actions',
      headerName: 'Actions',
      width: 180,
      renderCell: (params) => (
        <>
          <IconButton size="small" onClick={() => handleDetailOpen(params.row)}>
            <VisibilityIcon />
          </IconButton>
          <IconButton size="small" onClick={() => { setDeleteOrderId(params.row.order_id); setConfirmOpen(true); }}>
            <DeleteIcon />
          </IconButton>
        </>
      ),
    },
  ];

  return (
    <div style={{ margin: '20px' }}>
      <div style={{ height: 700, width: '100%' }}>
        <DataGrid
          rows={orders}
          columns={columns}
          getRowId={(row) => row.order_id}
          pageSize={pageSize}
          checkboxSelection
          disableSelectionOnClick
          paginationMode="server"
          rowCount={totalPages * pageSize}
          onPageChange={handlePageChange}
          page={currentPage - 1}
        />
      </div>
      <Box display="flex" justifyContent="center" marginTop={2}>
        <Pagination
          count={totalPages}
          page={currentPage}
          onChange={handlePageChange}
          color="primary"
        />
      </Box>
      <Dialog
        open={confirmOpen}
        onClose={handleConfirmClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">{"Confirm Delete"}</DialogTitle>
        <DialogContent>
          <Typography variant="body1">
            Are you sure you want to delete this order?
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleConfirmClose} color="primary">
            Cancel
          </Button>
          <Button onClick={() => handleDeleteOrder(deleteOrderId)} color="primary" autoFocus>
            Delete
          </Button>
        </DialogActions>
      </Dialog>
      <Dialog
        open={detailOpen}
        onClose={handleDetailClose}
        aria-labelledby="order-detail-title"
        aria-describedby="order-detail-description"
      >
        <DialogTitle id="order-detail-title">Order Details</DialogTitle>
        <DialogContent>
          {selectedOrder && (
            <>
              <Typography variant="h6">Order ID: {selectedOrder.order_id}</Typography>
              <Typography variant="body1">Customer: {selectedOrder.customer.firstname} {selectedOrder.customer.lastname}</Typography>
              <Typography variant="body1">Email: {selectedOrder.customer.email}</Typography>
              <Typography variant="body1">Total: ${selectedOrder.total}</Typography>
              <Typography variant="body1">Status: {selectedOrder.status}</Typography>
              <Typography variant="body1">Order Date: {format(new Date(selectedOrder.order_date), 'yyyy-MM-dd HH:mm:ss')}</Typography>
              <Typography variant="body2" style={{ marginTop: '10px' }}>Items:</Typography>
              <ul>
                {selectedOrder.items.map(item => (
                  <li key={item.id}>
                    {item.ProductName} - {item.ProductQuantity} x ${item.ProductPrice}
                  </li>
                ))}
              </ul>
            </>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleDetailClose} color="primary">
            Close
          </Button>
        </DialogActions>
      </Dialog>
      <Snackbar
        open={alert.open}
        autoHideDuration={6000}
        onClose={handleCloseAlert}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert onClose={handleCloseAlert} severity={alert.severity} sx={{ width: '100%' }}>
          {alert.message}
        </Alert>
      </Snackbar>
    </div>
  );
};

export default OrderCard;

// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import {
//   Button, Dialog, DialogActions, DialogContent, DialogTitle,
//   Typography, Snackbar, Alert, IconButton
// } from '@mui/material';
// import { DataGrid } from '@mui/x-data-grid';
// import VisibilityIcon from '@mui/icons-material/Visibility';
// import DeleteIcon from '@mui/icons-material/Delete';
// import { format } from 'date-fns';

// const OrderCard = () => {
//   const [orders, setOrders] = useState([]);
//   const [detailOpen, setDetailOpen] = useState(false);
//   const [selectedOrder, setSelectedOrder] = useState(null);
//   const [confirmOpen, setConfirmOpen] = useState(false);
//   const [deleteOrderId, setDeleteOrderId] = useState(null);
//   const [alert, setAlert] = useState({ open: false, message: '', severity: 'success' });

//   useEffect(() => {
//     const fetchOrders = async () => {
//       try {
//         const token = await localStorage.getItem('token');
//         const response = await axios.get('http://localhost:9000/api/getOrders', {
//           headers: {
//             'Authorization': `Bearer ${token}`
//           }
//         });
//         const formattedOrders = response.data.orders.map(order => ({
//           order_id: order.id,
//           customer_name: `${order.User.firstname} ${order.User.lastname}`,
//           status: order.payment_status,
//           total: order.TotalPrice,
//           order_date: order.created_at,
//           customer: order.User,
//           items: order.OrderItems,
//         }));
//         setOrders(formattedOrders);
//       } catch (error) {
//         console.error('Error fetching orders:', error);
//       }
//     };
//     fetchOrders();
//   }, []);

//   const handleDetailOpen = (order) => {
//     setSelectedOrder(order);
//     setDetailOpen(true);
//   };

//   const handleDetailClose = () => {
//     setSelectedOrder(null);
//     setDetailOpen(false);
//   };

//   const handleDeleteOrder = async (orderId) => {
//     try {
//       const updatedOrders = orders.filter(order => order.order_id !== orderId);
//       setOrders(updatedOrders);
//       setAlert({ open: true, message: 'Order deleted successfully!', severity: 'success' });
//     } catch (error) {
//       console.error('Error deleting order:', error);
//       setAlert({ open: true, message: 'Error deleting order!', severity: 'error' });
//     } finally {
//       setConfirmOpen(false);
//     }
//   };

//   const handleConfirmClose = () => {
//     setConfirmOpen(false);
//   };

//   const handleCloseAlert = () => {
//     setAlert({ ...alert, open: false });
//   };

//   const columns = [
//     { field: 'order_id', headerName: 'Order ID', width: 100 },
//     {
//       field: 'customer_name',
//       headerName: 'Customer Name',
//       width: 150,
//     },
//     { field: 'status', headerName: 'Status', width: 120 },
//     { field: 'total', headerName: 'Total', width: 100 },
//     {
//       field: 'order_date',
//       headerName: 'Order Date',
//       width: 200,
//       renderCell: (params) => format(new Date(params.value), 'yyyy-MM-dd HH:mm:ss')
//     },
//     {
//       field: 'actions',
//       headerName: 'Actions',
//       width: 180,
//       renderCell: (params) => (
//         <>
//           <IconButton size="small" onClick={() => handleDetailOpen(params.row)}>
//             <VisibilityIcon />
//           </IconButton>
//           <IconButton size="small" onClick={() => { setDeleteOrderId(params.row.order_id); setConfirmOpen(true); }}>
//             <DeleteIcon />
//           </IconButton>
//         </>
//       ),
//     },
//   ];

//   return (
//     <div style={{ margin: '20px' }}>
//       <div style={{ height: 700, width: '100%' }}>
//         <DataGrid
//           rows={orders}
//           columns={columns}
//           getRowId={(row) => row.order_id}
//           pageSize={5}
//           checkboxSelection
//         />
//       </div>
//       <Dialog
//         open={confirmOpen}
//         onClose={handleConfirmClose}
//         aria-labelledby="alert-dialog-title"
//         aria-describedby="alert-dialog-description"
//       >
//         <DialogTitle id="alert-dialog-title">{"Confirm Delete"}</DialogTitle>
//         <DialogContent>
//           <Typography variant="body1">
//             Are you sure you want to delete this order?
//           </Typography>
//         </DialogContent>
//         <DialogActions>
//           <Button onClick={handleConfirmClose} color="primary">
//             Cancel
//           </Button>
//           <Button onClick={() => handleDeleteOrder(deleteOrderId)} color="primary" autoFocus>
//             Delete
//           </Button>
//         </DialogActions>
//       </Dialog>
//       <Dialog
//         open={detailOpen}
//         onClose={handleDetailClose}
//         aria-labelledby="order-detail-title"
//         aria-describedby="order-detail-description"
//       >
//         <DialogTitle id="order-detail-title">Order Details</DialogTitle>
//         <DialogContent>
//           {selectedOrder && (
//             <>
//               <Typography variant="h6">Order ID: {selectedOrder.order_id}</Typography>
//               <Typography variant="body1">Customer: {selectedOrder.customer.firstname} {selectedOrder.customer.lastname}</Typography>
//               <Typography variant="body1">Email: {selectedOrder.customer.email}</Typography>
//               <Typography variant="body1">Total: ${selectedOrder.total}</Typography>
//               <Typography variant="body1">Status: {selectedOrder.status}</Typography>
//               <Typography variant="body1">Order Date: {format(new Date(selectedOrder.order_date), 'yyyy-MM-dd HH:mm:ss')}</Typography>
//               <Typography variant="body2" style={{ marginTop: '10px' }}>Items:</Typography>
//               <ul>
//                 {selectedOrder.items.map(item => (
//                   <li key={item.id}>
//                     {item.ProductName} - {item.ProductQuantity} x ${item.ProductPrice}
//                   </li>
//                 ))}
//               </ul>
//             </>
//           )}
//         </DialogContent>
//         <DialogActions>
//           <Button onClick={handleDetailClose} color="primary">
//             Close
//           </Button>
//         </DialogActions>
//       </Dialog>
//       <Snackbar
//         open={alert.open}
//         autoHideDuration={6000}
//         onClose={handleCloseAlert}
//         anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
//       >
//         <Alert onClose={handleCloseAlert} severity={alert.severity} sx={{ width: '100%' }}>
//           {alert.message}
//         </Alert>
//       </Snackbar>
//     </div>
//   );
// };

// export default OrderCard;
